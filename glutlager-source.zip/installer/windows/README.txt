Windows: Glutlager-Setup-0.2.3.exe doppelklicken. Installiert ohne Admin-Rechte nach
%LOCALAPPDATA%\Programs\Glutlager, legt Startmenü- und Desktop-Verknüpfung an.
Hinweis: Der Installer ist nicht digital signiert, daher zeigt Windows evtl. die
SmartScreen-Warnung "Weitere Informationen" -> "Trotzdem ausführen".
Spielstand: %APPDATA%\Glutlager\glutlager_save.json
