Arch Linux:
  Fertiges Paket:   sudo pacman -U glutlager-0.2.3-1-x86_64.pkg.tar.xz
  Oder selbst bauen: PKGBUILD + glutlager-linux-x86_64.tar.gz in einen Ordner legen, dann: makepkg -si
Andere Linux-Distributionen: glutlager-linux-x86_64.tar.gz entpacken und ./install.sh ausführen
(installiert für den aktuellen Benutzer, ohne root).
Spielstand: ~/.local/share/Glutlager/glutlager_save.json
