#!/bin/sh
# Installiert Glutlager für den aktuellen Benutzer (ohne root).
# Deinstallieren:  ./install.sh --uninstall
set -e
cd "$(dirname "$0")"
BIN="$HOME/.local/bin"; APPS="$HOME/.local/share/applications"; ICONS="$HOME/.local/share/icons/hicolor/256x256/apps"
if [ "$1" = "--uninstall" ]; then
  rm -f "$BIN/glutlager" "$APPS/glutlager.desktop" "$ICONS/glutlager.png"
  echo "Glutlager entfernt. Spielstände bleiben in ~/.local/share/Glutlager erhalten."
  exit 0
fi
mkdir -p "$BIN" "$APPS" "$ICONS"
install -m755 glutlager "$BIN/glutlager"
install -m644 glutlager.png "$ICONS/glutlager.png"
sed "s|^Exec=.*|Exec=$BIN/glutlager|" glutlager.desktop > "$APPS/glutlager.desktop"
chmod 644 "$APPS/glutlager.desktop"
echo "Glutlager installiert. Du findest es jetzt im Anwendungsmenü (oder starte: $BIN/glutlager)."
