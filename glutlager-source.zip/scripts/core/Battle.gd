class_name Battle
extends RefCounted
## Das Kampfsystem – reine Logik, ohne Oberfläche (so kann man es auch testen).
##
## Kernidee "Überhitzung":
##  * Karten erzeugen Hitze. Jeder Hitze-Punkt macht Schaden und Schild +10 %.
##  * Übersteigt die Hitze das Limit, gibt es eine KERNSCHMELZE:
##    3 Schaden pro überschüssigem Punkt (ignoriert Schild), Hitze fällt auf die Hälfte.
##  * Resonanz: Zwei Karten mit gleichem Tag nacheinander => +2 auf den Haupteffekt.
##
## Die Oberfläche liest "events" (was gerade passiert ist), um Zahlen, Töne und
## Animationen abzuspielen. Ohne Oberfläche (Simulation) bleibt record_events aus.

const HAND_SIZE := 5
const MELTDOWN_DMG := 3
const RESONANCE_BONUS := 2

var hp: int = 0
var max_hp: int = 0
var block: int = 0
var heat: int = 0
var heat_limit: int = 10
var cooling: int = 3
var energy: int = 0
var max_energy: int = 3
var turn: int = 0
var draw_pile: Array = []
var hand: Array = []
var discard_pile: Array = []
var exhaust_pile: Array = []
var enemies: Array = []
var played: Array = []
var last_tag: String = ""
var hot_runner: bool = false
var state: String = "player"  # player | enemy | won | lost
var meltdowns: int = 0
var enemy_queue: Array = []
var record_events: bool = false
var events: Array = []


func setup(p_hp: int, p_max: int, deck: Array, p_limit: int, p_cooling: int, enemy_ids: Array, floor_n: int, shuffle: bool = true) -> void:
	hp = p_hp
	max_hp = p_max
	heat_limit = p_limit
	cooling = p_cooling
	draw_pile = deck.duplicate()
	if shuffle:
		draw_pile.shuffle()
	for id in enemy_ids:
		enemies.append(EnemyDB.spawn(id, floor_n))
	start_player_turn()


# ---------------------------------------------------------------- Hilfsfunktionen
func mult() -> float:
	return 1.0 + 0.1 * float(heat)


func resonance_bonus_for(id: String) -> int:
	return RESONANCE_BONUS if (last_tag != "" and CardDB.CARDS[id].tag == last_tag) else 0


func alive_enemies() -> Array:
	return enemies.filter(func(e): return e.hp > 0)


func target_index(pref: int) -> int:
	if pref >= 0 and pref < enemies.size() and enemies[pref].hp > 0:
		return pref
	for i in enemies.size():
		if enemies[i].hp > 0:
			return i
	return -1


func can_play(hand_idx: int) -> bool:
	if state != "player" or hand_idx < 0 or hand_idx >= hand.size():
		return false
	return int(CardDB.CARDS[hand[hand_idx]].cost) <= energy


## Hitze, die diese Karte (vom aktuellen Stand aus) bewirken würde: + wärmer, - kühler
func heat_delta_of(id: String) -> int:
	var c: Dictionary = CardDB.CARDS[id]
	if c.get("special", "") == "heat_dump":
		return -heat
	return int(c.get("heat", 0)) - int(c.get("cool", 0))


func would_meltdown(id: String) -> bool:
	return heat + heat_delta_of(id) > heat_limit


func _ev(d: Dictionary) -> void:
	if record_events:
		events.append(d)


# ---------------------------------------------------------------- Ziehen / Zugbeginn
func _draw(n: int) -> void:
	for i in n:
		if draw_pile.is_empty():
			if discard_pile.is_empty():
				return
			draw_pile = discard_pile.duplicate()
			discard_pile.clear()
			draw_pile.shuffle()
		hand.append(draw_pile.pop_back())


func start_player_turn() -> void:
	turn += 1
	block = 0
	energy = max_energy + (1 if hot_runner else 0)
	played.clear()
	last_tag = ""
	_ev({"t": "turn"})
	if hot_runner:
		_gain_heat(1)
		if state == "lost":
			return
	_draw(HAND_SIZE)


# ---------------------------------------------------------------- Karte spielen
func play_card(hand_idx: int, target_pref: int = 0) -> bool:
	if not can_play(hand_idx):
		return false
	var id: String = hand[hand_idx]
	var c: Dictionary = CardDB.CARDS[id]
	energy -= int(c.cost)
	hand.remove_at(hand_idx)

	var m: float = mult()  # Hitze VOR der Karte zählt
	var bonus: int = resonance_bonus_for(id)
	var sp: String = c.get("special", "")
	var dmg: int = c.get("dmg", 0)
	var blk: int = c.get("blk", 0)
	var hits: int = c.get("hits", 1)
	var aoe: bool = c.get("aoe", false)
	var tgt: int = target_index(target_pref)
	_ev({"t": "card", "id": id, "target": tgt, "aoe": aoe, "resonance": bonus > 0})

	# Schaden
	if sp == "heat_dump":
		dmg = 3 * heat
		_ev({"t": "cool", "v": heat})
		heat = 0
		bonus = 0
	elif sp == "per_card":
		dmg += 3 * played.size()
	if dmg > 0:
		var amount: int = floori((dmg + bonus) * m)
		for h in hits:
			if aoe:
				for i in enemies.size():
					if enemies[i].hp > 0:
						_damage_enemy(i, amount)
			else:
				var t: int = target_index(tgt)
				if t >= 0:
					_damage_enemy(t, amount)
	# Schild
	if blk > 0:
		var b_bonus: int = bonus if dmg == 0 else 0
		var gain: int = floori((blk + b_bonus) * m)
		block += gain
		_ev({"t": "block", "v": gain})
	# Brand
	if c.has("burn"):
		if aoe:
			for i in enemies.size():
				if enemies[i].hp > 0:
					enemies[i].burn += int(c.burn)
					_ev({"t": "burn", "i": i, "v": int(c.burn)})
		else:
			var t2: int = target_index(tgt)
			if t2 >= 0:
				enemies[t2].burn += int(c.burn)
				_ev({"t": "burn", "i": t2, "v": int(c.burn)})
	# Sonstiges
	if c.has("cool"):
		var removed: int = mini(heat, int(c.cool))
		heat -= removed
		if removed > 0:
			_ev({"t": "cool", "v": removed})
	if c.has("heal"):
		var healed: int = mini(max_hp - hp, int(c.heal))
		hp += healed
		_ev({"t": "heal", "v": healed})
	if c.has("energy"):
		energy += int(c.energy)
		_ev({"t": "energy", "v": int(c.energy)})
	if sp == "hot_runner":
		hot_runner = true
	if c.has("draw"):
		_draw(int(c.draw))

	# Karte ablegen
	if c.get("exhaust", false):
		exhaust_pile.append(id)
	else:
		discard_pile.append(id)
	played.append(id)
	last_tag = c.tag

	# Hitze zuletzt, weil sie Kernschmelze auslösen kann
	if c.has("heat"):
		_gain_heat(int(c.heat))
	_check_end()
	return true


# ---------------------------------------------------------------- Hitze & Schaden
func _gain_heat(n: int) -> void:
	heat += n
	_ev({"t": "heat", "v": n})
	if heat > heat_limit:
		var excess: int = heat - heat_limit
		var d: int = excess * MELTDOWN_DMG
		hp -= d
		heat = heat_limit / 2
		meltdowns += 1
		_ev({"t": "melt", "v": d})
		if hp <= 0:
			hp = 0
			state = "lost"


func _damage_enemy(i: int, amount: int) -> void:
	var e: Dictionary = enemies[i]
	var rest: int = amount
	var absorbed: int = 0
	if e.block > 0:
		absorbed = mini(e.block, rest)
		e.block -= absorbed
		rest -= absorbed
	e.hp = maxi(0, e.hp - rest)
	_ev({"t": "edmg", "i": i, "v": rest, "blocked": absorbed, "dead": e.hp <= 0})


func _damage_player(amount: int) -> void:
	var rest: int = amount
	var absorbed: int = 0
	if block > 0:
		absorbed = mini(block, rest)
		block -= absorbed
		rest -= absorbed
	hp -= rest
	_ev({"t": "pdmg", "v": rest, "blocked": absorbed})
	if hp <= 0:
		hp = 0
		state = "lost"


func _check_end() -> void:
	if state == "lost":
		return
	if alive_enemies().is_empty():
		state = "won"


# ---------------------------------------------------------------- Zugende & Gegner
## Schrittweise (für Animationen): end_turn_begin() -> enemy_next() ... -> end_turn_finish()
func end_turn_begin() -> void:
	if state != "player":
		return
	discard_pile.append_array(hand)
	hand.clear()
	var removed: int = mini(heat, cooling)
	heat -= removed
	if removed > 0:
		_ev({"t": "cool", "v": removed})
	enemy_queue.clear()
	for i in enemies.size():
		if enemies[i].hp > 0:
			enemy_queue.append(i)
	state = "enemy"


## Lässt den nächsten Gegner handeln. Gibt dessen Index zurück, oder -1 wenn alle durch sind.
func enemy_next() -> int:
	while not enemy_queue.is_empty():
		var i: int = enemy_queue.pop_front()
		if enemies[i].hp <= 0:
			continue
		_enemy_act(i)
		return i
	return -1


func end_turn_finish() -> void:
	if state != "enemy":
		return
	_check_end()
	if state == "enemy":
		state = "player"
		start_player_turn()


## Alles in einem Rutsch (für die Simulation)
func end_turn() -> void:
	end_turn_begin()
	while enemy_next() != -1:
		if state == "lost":
			break
	end_turn_finish()


func _enemy_act(i: int) -> void:
	var e: Dictionary = enemies[i]
	e.block = 0
	if e.burn > 0:
		e.hp = maxi(0, e.hp - e.burn)
		_ev({"t": "burntick", "i": i, "v": e.burn, "dead": e.hp <= 0})
		e.burn -= 1
		if e.hp <= 0:
			return
	var it: Dictionary = e.intent
	_ev({"t": "eact", "i": i, "intent": it})
	if it.has("block"):
		e.block += int(it.block)
		_ev({"t": "eblock", "i": i, "v": int(it.block)})
	if it.has("heat"):
		_gain_heat(int(it.heat))
	if it.has("dmg"):
		_damage_player(int(it.dmg))
	e.idx = (int(e.idx) + 1) % e.pattern.size()
	e.intent = e.pattern[e.idx]
