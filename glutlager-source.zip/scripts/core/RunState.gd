class_name RunState
extends RefCounted
## Alles, was nur für den aktuellen Run gilt (wird beim Run-Ende verworfen).

const BOSS_FLOOR := 8
const CHECKPOINTS := [3, 6]

var class_id: String = "techniker"
var hp: int = 0
var max_hp: int = 0
var heat_limit: int = 10
var cooling: int = 3
var deck: Array = []
var floor_n: int = 1
var scrap: int = 0
var choices: Array = []
var pool: Array = []          # Karten, die als Belohnung auftauchen können
var reward_choices: int = 3
var fights_won: int = 0
var meltdowns: int = 0


static func create(p_class: String) -> RunState:
	var r := RunState.new()
	var cls: Dictionary = HeroDB.CLASSES[p_class]
	r.class_id = p_class
	r.max_hp = int(cls.hp) + 6 * Game.building_level("lazarett")
	r.hp = r.max_hp
	r.heat_limit = int(cls.heat_limit) + Game.building_level("kuehlturm")
	r.cooling = int(cls.cooling)
	r.deck = cls.deck.duplicate()
	r.pool = Game.data.unlocked_cards.duplicate()
	r.reward_choices = 3 + Game.building_level("funkturm")
	r.make_choices()
	return r


func is_boss_floor() -> bool:
	return floor_n >= BOSS_FLOOR


func make_choices() -> void:
	choices.clear()
	if is_boss_floor():
		choices.append({"type": "boss", "enemies": ["glutkern"]})
		return
	var count: int = 2 if floor_n < 6 else 3
	var types: Array = []
	if floor_n == 1:
		types = ["fight", "fight"]
	else:
		var weights := {"fight": 50, "event": 22, "rest": 14, "elite": 14 if floor_n >= 3 else 0}
		while types.size() < count:
			var t: String = _weighted(weights)
			if types.count(t) == 0 or t == "fight":
				types.append(t)
		if floor_n == BOSS_FLOOR - 1 and not types.has("rest"):
			types[types.size() - 1] = "rest"
	for t in types:
		var ch: Dictionary = {"type": t}
		if t == "fight" or t == "elite":
			ch["enemies"] = EnemyDB.pick_fight(floor_n, t == "elite")
		choices.append(ch)


func _weighted(weights: Dictionary) -> String:
	var total: int = 0
	for k in weights:
		total += int(weights[k])
	var roll: int = randi_range(1, total)
	for k in weights:
		roll -= int(weights[k])
		if roll <= 0:
			return k
	return "fight"


func reward_cards() -> Array:
	var options: Array = pool.duplicate()
	options.shuffle()
	return options.slice(0, reward_choices)
