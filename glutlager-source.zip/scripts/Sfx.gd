extends Node
## Autoload "Sfx": Alle Geräusche und die Musik werden beim Start per Code erzeugt
## (keine Audiodateien nötig). Ein- und ausschaltbar mit der Taste M.

const RATE := 22050

var sounds: Dictionary = {}
var players: Array = []
var music: AudioStreamPlayer
var enabled: bool = true
var music_on: bool = true


func _ready() -> void:
	for i in 8:
		var p := AudioStreamPlayer.new()
		p.volume_db = -6.0
		add_child(p)
		players.append(p)
	_build_sounds()
	music = AudioStreamPlayer.new()
	music.volume_db = -20.0
	add_child(music)
	music.stream = _build_music()
	enabled = bool(Game.data.get("sound", true))
	music_on = bool(Game.data.get("music", true))
	_apply_music()


func play(id: String, pitch: float = 1.0) -> void:
	if not enabled or not sounds.has(id):
		return
	for p in players:
		if not p.playing:
			p.stream = sounds[id]
			p.pitch_scale = pitch
			p.play()
			return


func toggle_all() -> void:
	enabled = not enabled
	music_on = enabled
	Game.data["sound"] = enabled
	Game.data["music"] = music_on
	Game.save_game()
	_apply_music()


func _apply_music() -> void:
	if music_on and enabled:
		if not music.playing:
			music.play()
	else:
		music.stop()


# ---------------------------------------------------------------- Klänge erzeugen
func _build_sounds() -> void:
	sounds["click"] = _make(_tone(700, 520, 0.06, 0.5))
	sounds["card"] = _make(_mix([_noise(0.16, 0.35, 0.8), _tone(380, 820, 0.14, 0.35)]))
	sounds["hit"] = _make(_mix([_noise(0.2, 0.9, 3.0), _tone(160, 55, 0.2, 0.9)]))
	sounds["block"] = _make(_mix([_tone(950, 650, 0.14, 0.5, "square"), _noise(0.06, 0.4, 5.0)]))
	sounds["heat"] = _make(_tone(260, 760, 0.2, 0.45, "saw"))
	sounds["cool"] = _make(_noise(0.3, 0.45, 1.6))
	sounds["melt"] = _make(_mix([_noise(0.9, 1.0, 1.2), _tone(90, 35, 0.9, 0.9), _tone(400, 80, 0.5, 0.4, "saw")]))
	sounds["hurt"] = _make(_mix([_tone(220, 80, 0.25, 0.8, "square"), _noise(0.15, 0.6, 3.0)]))
	sounds["coin"] = _make(_cat([_tone(988, 988, 0.07, 0.5), _tone(1319, 1319, 0.14, 0.5)]))
	sounds["buy"] = _make(_cat([_tone(660, 660, 0.06, 0.5), _tone(880, 880, 0.06, 0.5), _tone(1175, 1175, 0.14, 0.5)]))
	sounds["win"] = _make(_cat([_tone(523, 523, 0.12, 0.5), _tone(659, 659, 0.12, 0.5), _tone(784, 784, 0.12, 0.5), _tone(1047, 1047, 0.35, 0.5)]))
	sounds["lose"] = _make(_cat([_tone(392, 392, 0.2, 0.5, "saw"), _tone(311, 311, 0.2, 0.5, "saw"), _tone(220, 110, 0.6, 0.55, "saw")]))
	sounds["turn"] = _make(_tone(330, 440, 0.12, 0.4))
	sounds["error"] = _make(_tone(180, 150, 0.14, 0.5, "square"))


func _tone(f0: float, f1: float, dur: float, vol: float, wave: String = "sine") -> PackedFloat32Array:
	var n: int = int(RATE * dur)
	var out := PackedFloat32Array()
	out.resize(n)
	var phase: float = 0.0
	for i in n:
		var u: float = float(i) / float(n)
		var f: float = lerpf(f0, f1, u)
		phase += f / RATE
		var ph: float = fposmod(phase, 1.0)
		var v: float
		match wave:
			"square":
				v = 1.0 if ph < 0.5 else -1.0
				v *= 0.5
			"saw":
				v = (ph * 2.0 - 1.0) * 0.6
			_:
				v = sin(ph * TAU)
		var env: float = pow(1.0 - u, 1.6) * minf(1.0, float(i) / 120.0)
		out[i] = v * env * vol
	return out


func _noise(dur: float, vol: float, decay: float) -> PackedFloat32Array:
	var n: int = int(RATE * dur)
	var out := PackedFloat32Array()
	out.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 1234
	var lp: float = 0.0
	for i in n:
		var u: float = float(i) / float(n)
		lp = lerpf(lp, rng.randf_range(-1.0, 1.0), 0.55)
		out[i] = lp * exp(-u * decay * 2.0) * vol
	return out


func _mix(parts: Array) -> PackedFloat32Array:
	var n: int = 0
	for p in parts:
		n = maxi(n, p.size())
	var out := PackedFloat32Array()
	out.resize(n)
	for p in parts:
		for i in p.size():
			out[i] += p[i]
	return out


func _cat(parts: Array) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	for p in parts:
		out.append_array(p)
	return out


func _make(samples: PackedFloat32Array, loop: bool = false) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	var data := PackedByteArray()
	data.resize(samples.size() * 2)
	for i in samples.size():
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = samples.size()
	return w


## Ruhige Hintergrundmusik: dunkler Bass + langsame Moll-Töne
func _build_music() -> AudioStreamWAV:
	var dur: float = 16.0
	var n: int = int(RATE * dur)
	var out := PackedFloat32Array()
	out.resize(n)
	var notes: Array = [220.0, 261.6, 329.6, 261.6, 196.0, 246.9, 293.7, 246.9]
	var bass: Array = [55.0, 55.0, 49.0, 49.0]
	for i in n:
		var t: float = float(i) / RATE
		var b: float = bass[int(t / 4.0) % 4]
		var v: float = sin(t * TAU * b) * 0.28 + sin(t * TAU * b * 2.0) * 0.08
		v *= 0.75 + 0.25 * sin(t * TAU * 0.25)
		var step: int = int(t / 2.0)
		var nt: float = fposmod(t, 2.0)
		var f: float = notes[step % notes.size()]
		var env: float = exp(-nt * 1.3) * minf(1.0, nt * 30.0)
		v += (sin(t * TAU * f) * 0.5 + sin(t * TAU * f * 2.0) * 0.12) * env * 0.35
		out[i] = v * 0.7
	return _make(out, true)
