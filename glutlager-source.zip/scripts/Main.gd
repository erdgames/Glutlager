extends Control
## Der "Regisseur" des Spiels: weiß, welcher Bildschirm als Nächstes kommt.
##   (Erststart: Intro -> Übungskampf) -> Lager -> Run -> Karte -> (Kampf | Ereignis | Rast)
##   -> Belohnung -> Karte -> ... -> Wegkreuzung (Rückzug?) -> ... -> Boss -> Ergebnis -> Lager

const WIN_BONUS := 30
const TUTORIAL_GIFT := 20

var run: RunState = null
var screen: Control = null
var overlay: Control = null
var embers: CPUParticles2D = null


func _ready() -> void:
	_build_background()
	if Game.data.get("tutorial_done", false):
		show_camp()
	else:
		show_intro()


func _build_background() -> void:
	var bg := ColorRect.new()
	bg.color = UI.BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color(0.078, 0.067, 0.102, 0.0), Color(0.5, 0.17, 0.07, 0.6)])
	grad.offsets = PackedFloat32Array([0.3, 1.0])
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill_from = Vector2(0.5, 0.0)
	tex.fill_to = Vector2(0.5, 1.0)
	tex.width = 8
	tex.height = 256
	var glow := TextureRect.new()
	glow.texture = tex
	glow.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	glow.stretch_mode = TextureRect.STRETCH_SCALE
	glow.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(glow)
	# Aufsteigende Funken im Hintergrund
	embers = CPUParticles2D.new()
	embers.amount = 45
	embers.lifetime = 7.0
	embers.preprocess = 7.0
	embers.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	embers.emission_rect_extents = Vector2(640, 10)
	embers.position = Vector2(640, 730)
	embers.direction = Vector2(0.15, -1)
	embers.spread = 18.0
	embers.gravity = Vector2.ZERO
	embers.initial_velocity_min = 25.0
	embers.initial_velocity_max = 75.0
	embers.scale_amount_min = 1.5
	embers.scale_amount_max = 4.0
	var eg := Gradient.new()
	eg.colors = PackedColorArray([Color(1.0, 0.7, 0.3, 0.0), Color(1.0, 0.55, 0.2, 0.8), Color(1.0, 0.3, 0.1, 0.0)])
	eg.offsets = PackedFloat32Array([0.0, 0.2, 1.0])
	embers.color_ramp = eg
	add_child(embers)
	resized.connect(_on_resized)
	_on_resized()


func _on_resized() -> void:
	if embers != null:
		embers.position = Vector2(size.x * 0.5, size.y + 10.0)
		embers.emission_rect_extents = Vector2(size.x * 0.5, 10.0)


func _swap(n: Control) -> void:
	close_overlay()
	if screen != null:
		remove_child(screen)
		screen.queue_free()
	screen = n
	add_child(n)
	n.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	UI.fade_in(n)


func close_overlay() -> void:
	if overlay != null:
		overlay.queue_free()
		overlay = null


func show_overlay(n: Control) -> void:
	close_overlay()
	overlay = n
	add_child(n)


# ================================================================ Intro & Tutorial
func show_intro() -> void:
	var s := IntroScreen.new()
	s.done.connect(show_tutorial_battle)
	_swap(s)


func show_tutorial_battle() -> void:
	run = RunState.create("techniker")
	var s: BattleScreen = BattleScreen.make_tutorial(run)
	s.finished.connect(_on_tutorial_finished)
	_swap(s)


func _on_tutorial_finished(result: String) -> void:
	var first_time: bool = not Game.data.get("tutorial_done", false)
	Game.data["tutorial_done"] = true
	if first_time:
		Game.data.scrap = int(Game.data.scrap) + TUTORIAL_GIFT
	Game.save_game()
	run = null
	var box := _info_box("Geschafft!", "")
	box.add_child(_chip_row([["scrap", "+%d" % TUTORIAL_GIFT if first_time else "", UI.GOLD]] if first_time else []))
	var tips := UI.hbox(26)
	tips.alignment = BoxContainer.ALIGNMENT_CENTER
	tips.add_child(_tip("scrap", "Beute sammeln"))
	tips.add_child(_tip("gear", "Lager ausbauen"))
	tips.add_child(_tip("flame", "Neue Karten"))
	box.add_child(tips)
	box.add_child(UI.button("Ins Lager", show_camp, Vector2(300, 60), true, 24))
	Sfx.play("win")
	_swap(_wrap(box))


func _tip(kind: String, text: String) -> Control:
	var v := UI.vbox(6)
	var c := CenterContainer.new()
	var ring := PanelContainer.new()
	var col: Color = GIcon.default_color(kind)
	ring.add_theme_stylebox_override("panel", UI.style(col.darkened(0.75), col.darkened(0.2), 50, 3, 14))
	ring.add_child(GIcon.make(kind, 52, col))
	c.add_child(ring)
	v.add_child(c)
	v.add_child(UI.label(text, 20, UI.TEXT, HORIZONTAL_ALIGNMENT_CENTER, true))
	return v


# ================================================================ Lager
func show_camp() -> void:
	run = null
	var c := CampScreen.new()
	c.start_run.connect(_on_start_run)
	c.tutorial_requested.connect(show_intro)
	_swap(c)


func _on_start_run(class_id: String) -> void:
	run = RunState.create(class_id)
	Sfx.play("turn")
	show_map()


# ================================================================ Karte
func show_map() -> void:
	var m := MapScreen.new()
	m.setup(run)
	m.picked.connect(_on_node_picked)
	m.deck_requested.connect(func(): show_overlay(UI.deck_overlay(run.deck, "Dein Deck (%d)" % run.deck.size(), Callable(), close_overlay)))
	_swap(m)


func _on_node_picked(i: int) -> void:
	var ch: Dictionary = run.choices[i]
	match ch.type:
		"fight":
			start_battle(ch, "Etage %d" % run.floor_n)
		"elite":
			start_battle(ch, "Etage %d · Elite" % run.floor_n)
		"boss":
			start_battle(ch, "BOSS")
		"event":
			show_event()
		"rest":
			show_rest()


# ================================================================ Kampf
func start_battle(ch: Dictionary, title: String) -> void:
	var b := Battle.new()
	b.setup(run.hp, run.max_hp, run.deck, run.heat_limit, run.cooling, ch.enemies, run.floor_n)
	var s := BattleScreen.new()
	s.setup(b, run, title)
	s.finished.connect(_on_battle_finished.bind(b, ch))
	_swap(s)


func _on_battle_finished(result: String, b: Battle, ch: Dictionary) -> void:
	run.hp = b.hp
	run.meltdowns += b.meltdowns
	if result == "lost":
		finish_run("dead")
		return
	run.fights_won += 1
	var loot: int = 0
	for e in b.enemies:
		loot += int(e.scrap)
	run.scrap += loot
	if ch.type == "boss":
		run.scrap += WIN_BONUS
		finish_run("win")
		return
	show_reward(loot)


func show_reward(loot: int) -> void:
	var options: Array = run.reward_cards()
	var box := _info_box("Beute!", "")
	box.add_child(_chip_row([["scrap", "+%d" % loot, UI.GOLD]]))
	box.add_child(UI.label("Wähle eine Karte", 24, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER))
	var row := UI.hbox(18)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	for id in options:
		row.add_child(UI.card(id, 1.0, 0, true, false, _on_reward_picked.bind(id), "", 1.1))
	box.add_child(row)
	var skip := UI.button("Überspringen", advance, Vector2(200, 44), false, 16)
	skip.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(skip)
	Sfx.play("coin")
	_swap(_wrap(box))


func _on_reward_picked(id: String) -> void:
	run.deck.append(id)
	Sfx.play("buy")
	advance()


## Nach jedem abgeschlossenen Ort: nächste Etage (und ggf. Rückzug-Entscheidung)
func advance() -> void:
	var cleared: int = run.floor_n
	run.floor_n += 1
	run.make_choices()
	if RunState.CHECKPOINTS.has(cleared):
		show_checkpoint()
	else:
		show_map()


# ================================================================ Rückzug-Entscheidung
func show_checkpoint() -> void:
	var box := _info_box("Wegkreuzung", "")
	var row := UI.hbox(26)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(_decision_tile("home", "Heimkehren", UI.GOOD, [["scrap", str(run.scrap), UI.GOLD]], "Beute sicher", func(): finish_run("retreat")))
	row.add_child(_decision_tile("skull", "Weiter", UI.EMBER, [["skull", "→", UI.BAD], ["scrap", str(floori(run.scrap * 0.3)), UI.GOLD]], "Bei Tod nur 30 %", show_map))
	box.add_child(row)
	_swap(_wrap(box))


func _decision_tile(icon: String, title: String, col: Color, chips: Array, note: String, cb: Callable) -> Control:
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(340, 330)
	btn.focus_mode = Control.FOCUS_NONE
	btn.add_theme_stylebox_override("normal", UI.style(Color(0.13, 0.11, 0.17), col.darkened(0.15), 22, 3, 0))
	btn.add_theme_stylebox_override("hover", UI.style(Color(0.18, 0.15, 0.23), col.lightened(0.3), 22, 5, 0))
	btn.add_theme_stylebox_override("pressed", UI.style(Color(0.11, 0.09, 0.15), col, 22, 3, 0))
	btn.pressed.connect(cb)
	btn.pressed.connect(func(): Sfx.play("click"))
	var m := UI.margin_box(18)
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := UI.vbox(12)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	m.add_child(v)
	var ring := PanelContainer.new()
	ring.add_theme_stylebox_override("panel", UI.style(col.darkened(0.7), col, 70, 3, 16))
	ring.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ring.add_child(GIcon.make(icon, 90, col.lightened(0.15)))
	v.add_child(ring)
	v.add_child(UI.label(title, 36, col.lightened(0.2), HORIZONTAL_ALIGNMENT_CENTER, true))
	var cc := CenterContainer.new()
	var ch := UI.hbox(8)
	for c in chips:
		if c[0] == "skull":
			ch.add_child(GIcon.make("skull", 34, UI.BAD))
		else:
			ch.add_child(UI.chip(c[0], c[1], c[2], 26, UI.PANEL_DARK, 30))
	cc.add_child(ch)
	v.add_child(cc)
	v.add_child(UI.label(note, 18, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER))
	btn.add_child(m)
	UI.ignore_mouse(m)
	return btn


# ================================================================ Ereignis
func show_event() -> void:
	var ev: Dictionary = EventDB.pick()
	var box := _info_box(str(ev.title), str(ev.text))
	for opt in ev.options:
		box.add_child(_event_option(opt))
	_swap(_wrap(box))


func _fx_chips(fx: Dictionary) -> HBoxContainer:
	var row := UI.hbox(6)
	var spec: Array = [
		["hp", "heart", "", UI.GOOD], ["max_hp", "heart", "max ", UI.GOOD], ["scrap", "scrap", "", UI.GOLD],
		["heat_limit", "heat", "Limit ", Color(1.0, 0.55, 0.3)], ["cooling", "snow", "", UI.BLUE],
	]
	for s in spec:
		if fx.has(s[0]):
			var v: int = int(fx[s[0]])
			var col: Color = s[3] if v > 0 else UI.BAD
			row.add_child(UI.chip(s[1], "%s%+d" % [s[2], v], col, 22))
	if fx.has("card"):
		row.add_child(UI.chip("cards", "+1", UI.TEXT, 22))
	return row


func _event_option(opt: Dictionary) -> Control:
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(640, 66)
	btn.focus_mode = Control.FOCUS_NONE
	btn.add_theme_stylebox_override("normal", UI.style(UI.PANEL_LIGHT, Color(1, 1, 1, 0.12), 14, 2, 0))
	btn.add_theme_stylebox_override("hover", UI.style(UI.PANEL_LIGHT.lightened(0.12), UI.EMBER, 14, 3, 0))
	btn.add_theme_stylebox_override("pressed", UI.style(UI.PANEL_LIGHT.darkened(0.1), UI.EMBER, 14, 3, 0))
	btn.add_theme_stylebox_override("disabled", UI.style(UI.PANEL, Color(1, 1, 1, 0.05), 14, 1, 0))
	var m := UI.margin_box(12)
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var row := UI.hbox(14)
	m.add_child(row)
	var l := UI.label(str(opt.label), 24, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(l)
	row.add_child(_fx_chips(opt.fx))
	btn.add_child(m)
	UI.ignore_mouse(m)
	if opt.has("req_scrap") and run.scrap < int(opt.req_scrap):
		btn.disabled = true
		btn.modulate = Color(1, 1, 1, 0.5)
	btn.pressed.connect(_on_event_option.bind(opt))
	btn.pressed.connect(func(): Sfx.play("click"))
	return btn


func _on_event_option(opt: Dictionary) -> void:
	apply_fx(opt.fx)
	var box := _info_box("", "")
	box.get_child(0).queue_free()
	box.add_child(_fx_chips_big(opt.fx))
	box.add_child(UI.button("Weiter", advance, Vector2(260, 56), true, 22))
	_swap(_wrap(box))


func _fx_chips_big(fx: Dictionary) -> Control:
	var cc := CenterContainer.new()
	if fx.is_empty():
		cc.add_child(UI.label("Weiter geht's.", 30, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER, true))
	else:
		var row := _fx_chips(fx)
		cc.add_child(row)
	return cc


func apply_fx(fx: Dictionary) -> void:
	if fx.has("max_hp"):
		run.max_hp += int(fx.max_hp)
		run.hp += int(fx.max_hp)
	if fx.has("hp"):
		# Ereignisse dürfen dich nicht töten
		run.hp = clampi(run.hp + int(fx.hp), 1, run.max_hp)
	if fx.has("scrap"):
		run.scrap = maxi(0, run.scrap + int(fx.scrap))
	if fx.has("heat_limit"):
		run.heat_limit += int(fx.heat_limit)
	if fx.has("cooling"):
		run.cooling += int(fx.cooling)
	if fx.has("card"):
		run.deck.append(run.pool.pick_random())


# ================================================================ Rast
func show_rest() -> void:
	var heal: int = floori(run.max_hp * 0.3)
	var box := _info_box("Rast", "")
	var row := UI.hbox(26)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(_decision_tile("heart", "Ausruhen", UI.GOOD, [["heart", "+%d" % heal, UI.GOOD]], "", _on_rest_heal.bind(heal)))
	row.add_child(_decision_tile("cards", "Karte entfernen", UI.BLUE, [["cards", "−1", UI.TEXT]], "Dein Deck wird schlanker", _on_rest_remove))
	box.add_child(row)
	_swap(_wrap(box))


func _on_rest_heal(heal: int) -> void:
	run.hp = mini(run.max_hp, run.hp + heal)
	Sfx.play("buy")
	advance()


func _on_rest_remove() -> void:
	if run.deck.size() <= 6:
		Sfx.play("error")
		return
	show_overlay(UI.deck_overlay(run.deck, "Welche Karte soll weg?", _on_remove_card, close_overlay))


func _on_remove_card(idx: int) -> void:
	run.deck.remove_at(idx)
	close_overlay()
	advance()


# ================================================================ Run-Ende
func finish_run(result: String) -> void:
	var total: int = run.scrap
	var kept: int = Game.finish_run(run, result)
	var headline: String
	var color: Color
	var icon: String
	match result:
		"win":
			headline = "SIEG!"
			color = UI.GOOD
			icon = "flame"
			Sfx.play("win")
		"retreat":
			headline = "Heimgekehrt"
			color = UI.GOLD
			icon = "home"
			Sfx.play("win")
		_:
			headline = "Gefallen"
			color = UI.BAD
			icon = "skull"
			Sfx.play("lose")
	var box := _info_box(headline, "")
	box.get_child(0).add_theme_color_override("font_color", color)
	var ring := PanelContainer.new()
	ring.add_theme_stylebox_override("panel", UI.style(color.darkened(0.75), color, 80, 4, 20))
	ring.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ring.add_child(GIcon.make(icon, 90, color))
	box.add_child(ring)
	var stats := UI.hbox(12)
	stats.alignment = BoxContainer.ALIGNMENT_CENTER
	stats.add_child(UI.chip("scrap", "%d" % kept + ("  von %d" % total if result == "dead" else ""), UI.GOLD, 30, UI.PANEL_DARK, 34))
	stats.add_child(UI.chip("sword", str(run.fights_won), UI.TEXT, 26))
	stats.add_child(UI.chip("heat", str(run.meltdowns), Color(1.0, 0.55, 0.3), 26))
	box.add_child(stats)
	box.add_child(UI.button("Ins Lager", show_camp, Vector2(300, 60), true, 24))
	_swap(_wrap(box))


# ================================================================ Hilfsfunktionen
func _info_box(title: String, text: String) -> VBoxContainer:
	var v := UI.vbox(18)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(UI.title(title, 56))
	if text != "":
		var t := UI.label(text, 24, UI.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
		v.add_child(t)
	return v


func _chip_row(items: Array) -> Control:
	var cc := CenterContainer.new()
	var row := UI.hbox(10)
	for it in items:
		if str(it[1]) != "":
			row.add_child(UI.chip(it[0], it[1], it[2], 34, UI.PANEL_DARK, 38))
	cc.add_child(row)
	return cc


func _wrap(inner: Control) -> Control:
	var c := CenterContainer.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	inner.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	c.add_child(inner)
	return c


func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_M:
		Sfx.toggle_all()
