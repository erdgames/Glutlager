class_name EventDB
extends RefCounted
## Zufällige Ereignisse auf der Karte (bewusst kurz gehalten).
## Jede Option hat "fx" (Effekte), die als Symbole angezeigt werden:
##   hp, max_hp, scrap, heat_limit, cooling  (Zahlen, auch negativ)
##   card = "random"  (zufällige freigeschaltete Karte ins Deck)
## "req_scrap" = so viel Beute muss man dabeihaben, damit die Option wählbar ist.

const EVENTS := [
	{
		"title": "Altes Funkgerät",
		"text": "Es knistert noch.",
		"options": [
			{"label": "Reparieren", "fx": {"hp": -6, "heat_limit": 1}},
			{"label": "Ausschlachten", "fx": {"scrap": 25}},
			{"label": "Liegen lassen", "fx": {}},
		],
	},
	{
		"title": "Schrotthändler",
		"text": "„Ich hätte da was für dich.“",
		"options": [
			{"label": "Karte kaufen", "fx": {"scrap": -20, "card": "random"}, "req_scrap": 20},
			{"label": "Blut spenden", "fx": {"hp": -8, "scrap": 30}},
			{"label": "Weitergehen", "fx": {}},
		],
	},
	{
		"title": "Heiße Quelle",
		"text": "Warmes, klares Wasser.",
		"options": [
			{"label": "Baden", "fx": {"hp": 12}},
			{"label": "Kühlwasser abfüllen", "fx": {"cooling": 1}},
			{"label": "Weitergehen", "fx": {}},
		],
	},
	{
		"title": "Verlassenes Zelt",
		"text": "Noch warm. Jemand ist in Eile weg.",
		"options": [
			{"label": "Plündern", "fx": {"hp": -5, "scrap": 15, "card": "random"}},
			{"label": "Ausruhen", "fx": {"hp": 6}},
			{"label": "Weitergehen", "fx": {}},
		],
	},
	{
		"title": "Kern-Splitter",
		"text": "Er pulsiert. Gefährlich – und mächtig.",
		"options": [
			{"label": "Berühren", "fx": {"hp": -10, "max_hp": 8}},
			{"label": "Bergen", "fx": {"heat_limit": 1, "scrap": -10}, "req_scrap": 10},
			{"label": "Nicht anfassen", "fx": {}},
		],
	},
]


static func pick() -> Dictionary:
	return EVENTS.pick_random()
