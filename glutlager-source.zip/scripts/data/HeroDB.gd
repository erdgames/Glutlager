class_name HeroDB
extends RefCounted
## Startklassen. Neue Klassen werden im Lager (Zelt) mit Schrott freigeschaltet.

const CLASSES := {
	"techniker": {
		"name": "Techniker", "unlock": 0, "hp": 70, "heat_limit": 10, "cooling": 3,
		"desc": "Ausgewogen. Kühlt schnell ab, solide Schilde.",
		"deck": ["funke", "funke", "schlag", "schlag", "schild", "schild", "ventil", "ventil", "kurzschluss", "flamme"],
	},
	"brenner": {
		"name": "Brenner", "unlock": 60, "hp": 46, "heat_limit": 12, "cooling": 2,
		"desc": "Glaskanone. Hohes Hitze-Limit, wenig Leben, viel Feuer.",
		"deck": ["funke", "funke", "funke", "glutpfeil", "glutpfeil", "flamme", "schild", "schild", "zischen", "uebertakten"],
	},
}
