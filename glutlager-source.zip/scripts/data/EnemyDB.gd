class_name EnemyDB
extends RefCounted
## Gegner. Jeder Gegner hat ein festes Muster von Aktionen ("pattern"),
## das sich wiederholt. Der Spieler sieht immer die NÄCHSTE Aktion (Intent).
##   dmg = Schaden an dir   block = Schild für den Gegner   heat = Hitze für DICH

const ENEMIES := {
	"ratte": {"name": "Schrott-Ratte", "hp": 21, "scrap": 9,
		"pattern": [{"n": "Biss", "dmg": 6}, {"n": "Nagen", "dmg": 8}, {"n": "Verkriechen", "block": 6}]},
	"wolf": {"name": "Rost-Wolf", "hp": 28, "scrap": 11,
		"pattern": [{"n": "Heißer Atem", "dmg": 4, "heat": 2}, {"n": "Sprung", "dmg": 9}]},
	"drohne": {"name": "Funken-Drohne", "hp": 24, "scrap": 11,
		"pattern": [{"n": "Überspannung", "heat": 3}, {"n": "Entladung", "dmg": 10}, {"n": "Schutzfeld", "dmg": 4, "block": 5}]},
	"pluenderer": {"name": "Plünderer", "hp": 38, "scrap": 13,
		"pattern": [{"n": "Hieb", "dmg": 7}, {"n": "Deckung", "block": 8}, {"n": "Wuchtschlag", "dmg": 12}]},
	"golem": {"name": "Eisen-Golem", "hp": 66, "scrap": 24, "elite": true,
		"pattern": [{"n": "Panzerung", "block": 10}, {"n": "Faustschlag", "dmg": 14}, {"n": "Dampfstoß", "dmg": 6, "heat": 3}, {"n": "Zermalmen", "dmg": 18}]},
	"puppe": {"name": "Übungspuppe", "hp": 50, "scrap": 0,
		"pattern": [{"n": "Schlag", "dmg": 6}]},
	"glutkern": {"name": "Der Glutkern", "hp": 108, "scrap": 45, "boss": true,
		"pattern": [{"n": "Glutwelle", "dmg": 6, "heat": 3}, {"n": "Hitzeschlag", "dmg": 12}, {"n": "Magmahaut", "dmg": 4, "block": 12}, {"n": "Kernschmelze", "dmg": 20}]},
}

const FIGHTS_EARLY := [["ratte"], ["wolf"], ["ratte", "ratte"]]
const FIGHTS_MID := [["drohne"], ["pluenderer"], ["wolf", "drohne"], ["wolf", "wolf"]]
const FIGHTS_LATE := [["pluenderer", "drohne"], ["pluenderer", "wolf"], ["drohne", "drohne"]]


static func spawn(id: String, floor_n: int) -> Dictionary:
	var def: Dictionary = ENEMIES[id]
	var scale_hp: float = 1.0 + 0.06 * float(floor_n - 1)
	var bonus_dmg: int = (floor_n - 1) / 3
	var pattern: Array = []
	for step in def.pattern:
		var s: Dictionary = step.duplicate()
		if s.has("dmg"):
			s["dmg"] = int(s["dmg"]) + bonus_dmg
		pattern.append(s)
	var hp: int = roundi(float(def.hp) * scale_hp)
	return {
		"id": id, "name": def.name, "hp": hp, "max_hp": hp, "block": 0, "burn": 0,
		"idx": 0, "pattern": pattern, "intent": pattern[0],
		"elite": def.get("elite", false), "boss": def.get("boss", false),
		"scrap": int(def.scrap),
	}


static func pick_fight(floor_n: int, elite: bool) -> Array:
	if elite:
		return ["golem"]
	if floor_n <= 2:
		return FIGHTS_EARLY.pick_random()
	if floor_n <= 5:
		return FIGHTS_MID.pick_random()
	return FIGHTS_LATE.pick_random()


static func intent_text(intent: Dictionary) -> String:
	var parts: Array = []
	if intent.has("dmg"):
		parts.append("Angriff %d" % int(intent.dmg))
	if intent.has("block"):
		parts.append("Schild %d" % int(intent.block))
	if intent.has("heat"):
		parts.append("Hitze +%d für dich" % int(intent.heat))
	return " · ".join(parts)
