class_name CardDB
extends RefCounted
## Alle Karten des Spiels. Neue Karte = einfach einen Eintrag in CARDS ergänzen.
##
## Felder:  name, tag (feuer/funk/schrott), cost (Energie), type (attack/skill/power)
##   dmg   = Schaden        hits = Anzahl Treffer     aoe = trifft alle Gegner
##   blk   = Schild         heat = erzeugte Hitze     cool = entfernte Hitze
##   draw  = Karten ziehen  energy = Energie zurück   burn = Brand auf Gegner
##   heal  = Heilung        exhaust = nach Einsatz aus dem Kampf entfernen
##   special = Sonderregel  unlock = Schrott-Preis in der Werkbank (0 = von Anfang an)

const TAGS := {
	"feuer": {"name": "Feuer", "color": Color(1.0, 0.48, 0.2)},
	"funk": {"name": "Funk", "color": Color(0.31, 0.76, 0.97)},
	"schrott": {"name": "Schrott", "color": Color(0.76, 0.70, 0.50)},
}

const CARDS := {
	# --- Von Anfang an verfügbar -------------------------------------------
	"funke": {"name": "Funken", "tag": "feuer", "cost": 1, "type": "attack", "dmg": 6, "heat": 1, "unlock": 0},
	"schlag": {"name": "Schraubenschlag", "tag": "schrott", "cost": 1, "type": "attack", "dmg": 5, "unlock": 0},
	"schild": {"name": "Blechschild", "tag": "schrott", "cost": 1, "type": "skill", "blk": 6, "unlock": 0},
	"ventil": {"name": "Ventil", "tag": "funk", "cost": 1, "type": "skill", "blk": 3, "cool": 3, "unlock": 0},
	"flamme": {"name": "Flammenstoß", "tag": "feuer", "cost": 2, "type": "attack", "dmg": 13, "heat": 3, "unlock": 0},
	"kurzschluss": {"name": "Kurzschluss", "tag": "funk", "cost": 1, "type": "attack", "dmg": 4, "heat": 2, "draw": 1, "unlock": 0},
	"panzerplatte": {"name": "Panzerplatte", "tag": "schrott", "cost": 2, "type": "skill", "blk": 13, "heat": 1, "unlock": 0},
	"uebertakten": {"name": "Übertakten", "tag": "funk", "cost": 0, "type": "skill", "energy": 2, "heat": 3, "exhaust": true, "unlock": 0},
	"glutpfeil": {"name": "Glutpfeil", "tag": "feuer", "cost": 1, "type": "attack", "dmg": 4, "heat": 1, "burn": 3, "unlock": 0},
	"zischen": {"name": "Zischen", "tag": "funk", "cost": 0, "type": "skill", "cool": 2, "draw": 1, "unlock": 0},
	"salve": {"name": "Schrottsalve", "tag": "schrott", "cost": 2, "type": "attack", "dmg": 4, "hits": 3, "heat": 1, "unlock": 0},
	"notkuehlung": {"name": "Notkühlung", "tag": "funk", "cost": 2, "type": "skill", "blk": 6, "cool": 6, "unlock": 0},
	# --- In der Werkbank freischaltbar -------------------------------------
	"kettenreaktion": {"name": "Kettenreaktion", "tag": "feuer", "cost": 1, "type": "attack", "dmg": 3, "heat": 1, "special": "per_card", "unlock": 25},
	"fusion": {"name": "Kernfusion", "tag": "feuer", "cost": 2, "type": "attack", "special": "heat_dump", "exhaust": true, "unlock": 40},
	"flammenwand": {"name": "Flammenwand", "tag": "feuer", "cost": 2, "type": "skill", "blk": 8, "heat": 2, "burn": 2, "aoe": true, "unlock": 30},
	"magnet": {"name": "Magnetfeld", "tag": "schrott", "cost": 1, "type": "skill", "draw": 2, "heat": 1, "unlock": 20},
	"heisslaeufer": {"name": "Heißläufer", "tag": "funk", "cost": 1, "type": "power", "special": "hot_runner", "exhaust": true, "unlock": 45},
	"lawine": {"name": "Schrottlawine", "tag": "schrott", "cost": 3, "type": "attack", "dmg": 9, "heat": 2, "aoe": true, "unlock": 30},
	"blitz": {"name": "Blitzschlag", "tag": "funk", "cost": 1, "type": "attack", "dmg": 10, "heat": 4, "unlock": 25},
	"reparatur": {"name": "Reparatur", "tag": "schrott", "cost": 1, "type": "skill", "heal": 5, "exhaust": true, "unlock": 20},
	"inferno": {"name": "Inferno", "tag": "feuer", "cost": 3, "type": "attack", "dmg": 11, "heat": 4, "burn": 2, "aoe": true, "unlock": 45},
	"kryo": {"name": "Kryo-Stoß", "tag": "funk", "cost": 1, "type": "attack", "dmg": 7, "cool": 2, "unlock": 25},
}


static func get_card(id: String) -> Dictionary:
	return CARDS[id]


static func starter_ids() -> Array:
	var out: Array = []
	for id in CARDS:
		if int(CARDS[id].get("unlock", 0)) == 0:
			out.append(id)
	return out


static func unlockable_ids() -> Array:
	var out: Array = []
	for id in CARDS:
		if int(CARDS[id].get("unlock", 0)) > 0:
			out.append(id)
	out.sort_custom(func(a, b): return CARDS[a].unlock < CARDS[b].unlock)
	return out


static func tag_color(id: String) -> Color:
	return TAGS[CARDS[id].tag].color


## Kurzer Zusatzhinweis für Sonderkarten (steht klein unten auf der Karte)
static func footnote(id: String) -> String:
	var c: Dictionary = CARDS[id]
	var parts: Array = []
	match c.get("special", ""):
		"per_card": parts.append("+3 je gespielter Karte")
		"heat_dump": parts.append("3 × Hitze, dann 0")
		"hot_runner": parts.append("+1 Energie & Hitze pro Zug")
	if c.get("aoe", false):
		parts.append("trifft alle")
	if c.get("exhaust", false):
		parts.append("verbraucht")
	return " · ".join(parts)


## Kartentext. m = aktueller Hitze-Multiplikator, bonus = Resonanz-Bonus (+2),
## damit die Karte in der Hand schon die echten Zahlen zeigt.
static func describe(id: String, m: float = 1.0, bonus: int = 0) -> String:
	var c: Dictionary = CARDS[id]
	var lines: Array = []
	var sp: String = c.get("special", "")
	var dmg: int = c.get("dmg", 0)
	var blk: int = c.get("blk", 0)
	var d_bonus: int = bonus if dmg > 0 else 0
	var b_bonus: int = bonus if (dmg == 0 and blk > 0) else 0
	if sp == "heat_dump":
		lines.append("Schaden = 3 × Hitze. Danach Hitze 0.")
	elif sp == "per_card":
		lines.append("Schaden %d, +3 je zuvor gespielter Karte." % floori((dmg + d_bonus) * m))
	elif dmg > 0:
		var t: String = "Schaden %d" % floori((dmg + d_bonus) * m)
		if int(c.get("hits", 1)) > 1:
			t += " ×%d" % int(c.hits)
		if c.get("aoe", false):
			t += " auf ALLE"
		lines.append(t + ".")
	if blk > 0:
		lines.append("Schild %d." % floori((blk + b_bonus) * m))
	if c.has("burn"):
		lines.append("Brand %d%s." % [int(c.burn), " auf ALLE" if c.get("aoe", false) else ""])
	if c.has("cool"):
		lines.append("Hitze −%d." % int(c.cool))
	if c.has("draw"):
		lines.append("Ziehe %d Karte%s." % [int(c.draw), "n" if int(c.draw) > 1 else ""])
	if c.has("energy"):
		lines.append("+%d Energie." % int(c.energy))
	if c.has("heal"):
		lines.append("Heile %d LP." % int(c.heal))
	if sp == "hot_runner":
		lines.append("Ab jetzt: +1 Energie pro Zug, aber +1 Hitze pro Zug.")
	if c.has("heat"):
		lines.append("Hitze +%d." % int(c.heat))
	if c.get("exhaust", false):
		lines.append("Verbraucht.")
	return "\n".join(lines)
