extends Node
## Autoload "Game": Dauerfortschritt + Speichern/Laden (JSON-Datei, komplett offline).
## Die Datei liegt im Benutzerordner des Betriebssystems (user://).

const SAVE_PATH := "user://glutlager_save.json"
const SAVE_VERSION := 1

## Gebäude: Kosten pro Stufe (Index 0 = Stufe 1)
const BUILDINGS := {
	"kuehlturm": {"name": "Kühlturm", "desc": "+1 Hitze-Limit pro Stufe", "costs": [30, 60, 100]},
	"lazarett": {"name": "Lazarett", "desc": "+6 Start-Leben pro Stufe", "costs": [25, 50, 80]},
	"funkturm": {"name": "Funkturm", "desc": "+1 Karte zur Auswahl bei Belohnungen", "costs": [40, 90]},
}

var data: Dictionary = {}


func _ready() -> void:
	load_game()


func default_data() -> Dictionary:
	return {
		"version": SAVE_VERSION,
		"scrap": 25,
		"buildings": {"kuehlturm": 0, "lazarett": 0, "funkturm": 0},
		"unlocked_cards": CardDB.starter_ids(),
		"unlocked_classes": ["techniker"],
		"tutorial_done": false,
		"sound": true,
		"music": true,
		"stats": {"runs": 0, "wins": 0, "retreats": 0, "best_floor": 0, "total_scrap": 0},
	}


func load_game() -> void:
	data = default_data()
	if not FileAccess.file_exists(SAVE_PATH):
		save_game()
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return  # kaputte Datei: Standardwerte behalten
	# Gespeicherte Werte über die Standardwerte legen (so brechen alte Spielstände nicht)
	for key in parsed:
		if typeof(data.get(key)) == TYPE_DICTIONARY and typeof(parsed[key]) == TYPE_DICTIONARY:
			data[key].merge(parsed[key], true)
		else:
			data[key] = parsed[key]


func save_game() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("Speichern fehlgeschlagen")
		return
	f.store_string(JSON.stringify(data, "\t"))
	f.close()


func reset_progress() -> void:
	data = default_data()
	save_game()


# ---------------------------------------------------------------- Lager
func building_level(id: String) -> int:
	return int(data.buildings.get(id, 0))


func building_next_cost(id: String) -> int:
	var costs: Array = BUILDINGS[id].costs
	var lvl: int = building_level(id)
	return -1 if lvl >= costs.size() else int(costs[lvl])


func buy_building(id: String) -> bool:
	var cost: int = building_next_cost(id)
	if cost < 0 or int(data.scrap) < cost:
		return false
	data.scrap = int(data.scrap) - cost
	data.buildings[id] = building_level(id) + 1
	save_game()
	return true


func buy_card(id: String) -> bool:
	var cost: int = int(CardDB.CARDS[id].unlock)
	if data.unlocked_cards.has(id) or int(data.scrap) < cost:
		return false
	data.scrap = int(data.scrap) - cost
	data.unlocked_cards.append(id)
	save_game()
	return true


func buy_class(id: String) -> bool:
	var cost: int = int(HeroDB.CLASSES[id].unlock)
	if data.unlocked_classes.has(id) or int(data.scrap) < cost:
		return false
	data.scrap = int(data.scrap) - cost
	data.unlocked_classes.append(id)
	save_game()
	return true


## Run beenden und Beute verbuchen. result: "win" | "retreat" | "dead"
func finish_run(run: RunState, result: String) -> int:
	var kept: int = run.scrap
	if result == "dead":
		kept = floori(run.scrap * 0.3)
	data.scrap = int(data.scrap) + kept
	var st: Dictionary = data.stats
	st.runs = int(st.runs) + 1
	st.total_scrap = int(st.total_scrap) + kept
	if result == "win":
		st.wins = int(st.wins) + 1
	if result == "retreat":
		st.retreats = int(st.retreats) + 1
	st.best_floor = maxi(int(st.best_floor), run.floor_n if result != "win" else RunState.BOSS_FLOOR + 1)
	save_game()
	return kept
