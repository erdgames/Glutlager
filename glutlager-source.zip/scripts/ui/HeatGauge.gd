class_name HeatGauge
extends Control
## Die Hitze-Leiste: ein Kästchen pro Hitze-Punkt. Voll = Limit erreicht.
## Beim Überfahren einer Karte zeigt sie als Vorschau, wie viele Kästchen dazukommen
## (rot + Totenkopf, wenn das eine Kernschmelze auslösen würde).

var heat: int = 0
var limit: int = 10
var preview: int = 0   # Hitze, die die Karte unter der Maus hinzufügen würde (negativ = abkühlen)
var t: float = 0.0
var show_mult: bool = true


func _ready() -> void:
	custom_minimum_size.y = maxf(custom_minimum_size.y, 86.0)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func setup(p_heat: int, p_limit: int) -> void:
	heat = p_heat
	limit = p_limit
	queue_redraw()


func set_preview(v: int) -> void:
	preview = v
	queue_redraw()


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


static func heat_color(ratio: float) -> Color:
	return Color.from_hsv(lerpf(0.33, 0.0, clampf(ratio, 0.0, 1.0)), 0.8, 1.0)


func _draw() -> void:
	var f: Font = ThemeDB.fallback_font
	var danger: bool = heat >= limit - 2
	var over: int = maxi(0, heat + preview - limit)
	var cells_total: int = limit + (over if preview > 0 else 0)
	var left: float = 8.0
	var right: float = size.x - 8.0
	var top: float = 34.0
	var h: float = size.y - top - 8.0
	var gap: float = 4.0
	var cw: float = (right - left - gap * (cells_total - 1)) / float(cells_total)
	# Titel + Multiplikator
	draw_string(f, Vector2(left, 22), "HITZE  %d / %d" % [heat, limit], HORIZONTAL_ALIGNMENT_LEFT, -1, 20, heat_color(float(heat) / float(limit)))
	draw_string(f, Vector2(left + 170, 22), "Über %d = Kernschmelze!" % limit, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1.0, 0.45, 0.4, 0.85))
	if show_mult:
		var m: float = 1.0 + 0.1 * float(heat)
		var pulse: float = 1.0 + 0.04 * sin(t * 6.0) if danger else 1.0
		draw_string(f, Vector2(size.x - 330, 24), "Schaden ×%.1f (Hitze verstärkt)" % m, HORIZONTAL_ALIGNMENT_RIGHT, 322, int(20 * pulse), Color(1.0, 0.85, 0.35))
	for i in cells_total:
		var x: float = left + i * (cw + gap)
		var r := Rect2(x, top, cw, h)
		var beyond: bool = i >= limit
		var ratio: float = float(i + 1) / float(limit)
		var col: Color = heat_color(ratio)
		if beyond:
			col = Color(1.0, 0.1, 0.1)
		if i < heat and not beyond:
			var glow: float = 0.0
			if danger:
				glow = 0.15 * (0.5 + 0.5 * sin(t * 8.0))
			draw_rect(r, col.lightened(glow))
			draw_rect(Rect2(x, top, cw, h * 0.35), Color(1, 1, 1, 0.18))
		else:
			draw_rect(r, Color(0.1, 0.09, 0.13))
			draw_rect(r, Color(1, 1, 1, 0.07), false, 1.0)
		# Vorschau
		if preview > 0 and i >= heat and i < heat + preview:
			var a: float = 0.45 + 0.35 * sin(t * 9.0)
			var pc: Color = Color(1.0, 0.1, 0.1) if (beyond or i >= limit) else col
			draw_rect(r, Color(pc.r, pc.g, pc.b, a))
			draw_rect(r, pc, false, 2.0)
		elif preview < 0 and i < heat and i >= heat + preview:
			draw_rect(r, Color(0.5, 0.9, 1.0, 0.55 + 0.25 * sin(t * 9.0)))
	# Limit-Markierung (Totenkopf am Ende)
	var lx: float = left + limit * (cw + gap) - gap * 0.5
	draw_line(Vector2(lx, top - 8), Vector2(lx, top + h + 4), Color(1, 0.3, 0.3, 0.9), 2.0)
	if over > 0 and preview > 0:
		draw_string(f, Vector2(lx + 6, top + h * 0.5 + 8), "BOOM", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 0.3, 0.3))
