class_name BattleScreen
extends Control
## Zeigt einen Kampf. Die Logik steckt in Battle.gd – dieser Bildschirm zeichnet den
## Zustand, spielt Effekte/Töne ab und führt im Tutorial-Modus Schritt für Schritt an.

signal finished(result: String)  # "won", "lost" oder "skip" (Tutorial übersprungen)

const TUT_STEPS := [
	{"text": "Das ist dein Gegner. Über ihm siehst du, was er als Nächstes tut.", "target": "enemy", "wait": "next"},
	{"text": "Das sind deine Karten. Die Zahl im Kreis sind die Energie-Kosten. Du hast 3 pro Zug.", "target": "hand", "wait": "next"},
	{"text": "Klick auf „Funken“, um die Karte zu spielen.", "target": "card:funke", "wait": "play:funke:1"},
	{"text": "Die Hitze ist gestiegen! Jedes Kästchen macht Schaden und Schild +10 %.", "target": "gauge", "wait": "next"},
	{"text": "Spiel jetzt den Flammenstoß. Mit mehr Hitze schlägt er härter zu.", "target": "card:flamme", "wait": "play:flamme:1"},
	{"text": "Vorsicht: Läuft die Leiste über, gibt es eine KERNSCHMELZE und du nimmst Schaden. Karten mit rotem Rand warnen dich.", "target": "gauge", "wait": "next"},
	{"text": "Keine Energie mehr. Beende den Zug.", "target": "end", "wait": "end"},
	{"text": "Neue Runde. Spiel zweimal „Funken“ hintereinander: Gleiches Symbol = Resonanz (goldener Rand) = Bonus.", "target": "card:funke", "wait": "play:funke:2"},
	{"text": "Das Ventil kühlt sofort ab und gibt Schild. Probier es aus!", "target": "card:ventil", "wait": "play:ventil:1"},
	{"text": "Fast geschafft: Besiege den Gegner! Danach zeigt dir das Lager, wie es weitergeht.", "target": "none", "wait": "free"},
]

# Reihenfolge der Karten im Übungskampf (1. Hand, 2. Hand, danach Rest)
const TUT_ORDER := ["funke", "flamme", "ventil", "funke", "schild", "funke", "funke", "ventil", "schlag", "schild", "flamme", "funke", "schlag", "kurzschluss", "ventil", "funke", "schlag", "schild", "funke", "flamme"]

var b: Battle
var run: RunState
var title_text: String = ""
var selected: int = 0
var content: Control = null
var fx_layer: Control
var coach_layer: Control
var vignette: TextureRect
var busy: bool = false
var ended: bool = false
var t: float = 0.0

# Verweise auf die zuletzt gebauten Elemente (für Effekte / Tutorial)
var gauge: HeatGauge = null
var enemy_nodes: Array = []
var enemy_arts: Array = []
var card_nodes: Array = []
var hand_row: Control = null
var end_btn: Control = null
var player_node: Control = null
var energy_node: Control = null

# Tutorial
var tutorial: bool = false
var tut_i: int = 0
var tut_count: int = 0
var coach_panel: PanelContainer = null
var highlight: Panel = null


func setup(battle: Battle, p_run: RunState, p_title: String, p_tutorial: bool = false) -> void:
	b = battle
	run = p_run
	title_text = p_title
	tutorial = p_tutorial


## Fertig vorbereiteter Übungskampf (feste Karten, harmlose Puppe)
static func make_tutorial(p_run: RunState) -> BattleScreen:
	var battle := Battle.new()
	var order: Array = TUT_ORDER.duplicate()
	order.reverse()  # Battle zieht vom Ende des Stapels
	battle.setup(40, 40, order, 10, 3, ["puppe"], 1, false)
	var s := BattleScreen.new()
	s.setup(battle, p_run, "Übung", true)
	return s


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	b.record_events = true
	# Rote Hitze-Vignette (liegt hinter der Oberfläche)
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color(1.0, 0.15, 0.0, 0.0), Color(1.0, 0.15, 0.0, 0.0), Color(1.0, 0.1, 0.0, 0.85)])
	grad.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = 256
	tex.height = 256
	vignette = TextureRect.new()
	vignette.texture = tex
	vignette.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vignette.stretch_mode = TextureRect.STRETCH_SCALE
	vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vignette.modulate.a = 0.0
	add_child(vignette)
	fx_layer = Control.new()
	fx_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fx_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fx_layer)
	coach_layer = Control.new()
	coach_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	coach_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(coach_layer)
	refresh()
	if tutorial:
		await get_tree().process_frame
		_tut_show()


func _process(delta: float) -> void:
	t += delta
	if vignette == null or b == null:
		return
	var ratio: float = float(b.heat) / float(b.heat_limit)
	var a: float = ratio * ratio * 0.5
	if b.heat >= b.heat_limit - 2:
		a += 0.12 + 0.1 * sin(t * 8.0)
	vignette.modulate.a = clampf(a, 0.0, 0.85)


# ================================================================ Aufbau
func refresh() -> void:
	if content != null:
		remove_child(content)
		content.queue_free()
	selected = b.target_index(selected)
	enemy_nodes.clear()
	enemy_arts.clear()
	card_nodes.clear()
	content = _build()
	add_child(content)
	move_child(content, 1)  # hinter fx_layer und coach_layer, vor der Vignette


func _build() -> Control:
	var margin := UI.margin_box(16)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var root := UI.vbox(8)
	margin.add_child(root)

	# Obere Leiste
	var top := UI.hbox(10)
	top.add_child(UI.label(title_text, 26, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true))
	top.add_child(UI.spacer(false))
	if not tutorial:
		top.add_child(UI.chip("scrap", str(run.scrap), UI.GOLD, 22))
	top.add_child(UI.button("?", _on_help, Vector2(46, 40), false, 22))
	top.add_child(UI.button("Ton", func(): Sfx.toggle_all(), Vector2(64, 40), false, 16))
	root.add_child(top)

	# Gegner
	var enemy_row := UI.hbox(26)
	enemy_row.alignment = BoxContainer.ALIGNMENT_CENTER
	enemy_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for i in b.enemies.size():
		var en: Control = _enemy_panel(i)
		enemy_nodes.append(en)
		enemy_row.add_child(en)
	root.add_child(enemy_row)

	# Mittelstreifen: Spieler | Hitze | Knöpfe
	var mid := UI.hbox(14)
	mid.custom_minimum_size = Vector2(0, 104)
	player_node = _player_panel()
	mid.add_child(player_node)
	var gp := UI.panel(UI.PANEL, 6, Color(1, 1, 1, 0.06), 1)
	gp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gauge = HeatGauge.new()
	gauge.setup(b.heat, b.heat_limit)
	gauge.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gp.add_child(gauge)
	mid.add_child(gp)
	mid.add_child(_side_panel())
	root.add_child(mid)

	# Hand
	hand_row = UI.hbox(10)
	hand_row.alignment = BoxContainer.ALIGNMENT_CENTER
	var n_cards: int = maxi(1, b.hand.size())
	var f: float = clampf((1240.0 - 10.0 * (n_cards - 1)) / float(n_cards) / UI.CARD_W, 0.7, 1.0)
	hand_row.custom_minimum_size = Vector2(0, UI.CARD_H * f + 6)
	var m: float = b.mult()
	for i in b.hand.size():
		var id: String = b.hand[i]
		var ok: bool = b.can_play(i)
		var card := UI.card(id, m, b.resonance_bonus_for(id), ok, b.would_meltdown(id) and ok, _on_card.bind(i), "", f)
		card.mouse_entered.connect(_on_card_hover.bind(i, true))
		card.mouse_exited.connect(_on_card_hover.bind(i, false))
		card_nodes.append(card)
		hand_row.add_child(card)
	root.add_child(hand_row)
	return margin


func _intent_chips(it: Dictionary) -> HBoxContainer:
	var row := UI.hbox(6)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	if it.has("dmg"):
		row.add_child(UI.chip("sword", "%d Schaden" % int(it.dmg), UI.BAD, 16, Color(0.25, 0.08, 0.1), 22))
	if it.has("block"):
		row.add_child(UI.chip("shield", "%d Schild" % int(it.block), UI.BLUE, 16, Color(0.08, 0.14, 0.25), 22))
	if it.has("heat"):
		row.add_child(UI.chip("heat", "+%d Hitze" % int(it.heat), Color(1.0, 0.55, 0.3), 16, Color(0.28, 0.12, 0.05), 22))
	return row


func _enemy_panel(i: int) -> Control:
	var e: Dictionary = b.enemies[i]
	var alive: bool = e.hp > 0
	var multi: bool = b.alive_enemies().size() > 1
	var is_sel: bool = alive and i == selected and multi
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(270, 0)
	btn.focus_mode = Control.FOCUS_NONE
	var border: Color = UI.EMBER if is_sel else Color(1, 1, 1, 0.07)
	btn.add_theme_stylebox_override("normal", UI.style(Color(0.12, 0.1, 0.15, 0.85), border, 16, 3 if is_sel else 1, 0))
	btn.add_theme_stylebox_override("hover", UI.style(Color(0.15, 0.12, 0.19, 0.9), UI.EMBER.darkened(0.2), 16, 3, 0))
	btn.add_theme_stylebox_override("pressed", UI.style(Color(0.12, 0.1, 0.15), UI.EMBER, 16, 3, 0))
	btn.pressed.connect(_on_select.bind(i))
	if not alive:
		btn.modulate = Color(1, 1, 1, 0.25)
		btn.disabled = true

	var m := UI.margin_box(10)
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := UI.vbox(4)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	m.add_child(v)
	# Absicht (was passiert als Nächstes?)
	if alive:
		v.add_child(UI.label("Plant als Nächstes:", 14, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER))
	var intent_box := CenterContainer.new()
	intent_box.custom_minimum_size = Vector2(0, 36)
	if alive:
		intent_box.add_child(_intent_chips(e.intent))
	v.add_child(intent_box)
	var art_px: int = 150 if (e.boss) else (136 if e.elite else 120)
	var art := EnemyArt.make(str(e.id), art_px)
	enemy_arts.append(art)
	v.add_child(art)
	var name_col: Color = UI.GOLD if (e.elite or e.boss) else UI.TEXT
	v.add_child(UI.label(str(e.name), 20, name_col, HORIZONTAL_ALIGNMENT_CENTER, true))
	v.add_child(UI.bar(e.hp, e.max_hp, UI.BAD, "%d / %d" % [e.hp, e.max_hp], Vector2(0, 24)))
	var status := UI.hbox(14)
	status.alignment = BoxContainer.ALIGNMENT_CENTER
	status.custom_minimum_size = Vector2(0, 26)
	if e.block > 0:
		status.add_child(UI.icon_row("shield", str(int(e.block)), 20, 18, UI.BLUE))
	if e.burn > 0:
		status.add_child(UI.icon_row("burn", str(int(e.burn)), 20, 18, UI.GOLD))
	v.add_child(status)
	btn.add_child(m)
	UI.ignore_mouse(m)
	return btn


func _player_panel() -> Control:
	var p := UI.panel(UI.PANEL, 10, Color(1, 1, 1, 0.06), 1)
	p.custom_minimum_size = Vector2(290, 0)
	var v := UI.vbox(6)
	p.add_child(v)
	var hp_col: Color = UI.GOOD if b.hp > b.max_hp * 0.35 else UI.BAD
	v.add_child(UI.bar(b.hp, b.max_hp, hp_col, "%d / %d" % [b.hp, b.max_hp], Vector2(0, 28)))
	var row := UI.hbox(16)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	var sh := UI.icon_row("shield", str(b.block), 30, 28, UI.BLUE if b.block > 0 else UI.DIM)
	row.add_child(sh)
	energy_node = UI.hbox(4)
	var cap: int = b.max_energy + (1 if b.hot_runner else 0)
	for k in maxi(cap, b.energy):
		var ic := GIcon.make("energy", 30, GIcon.default_color("energy"))
		if k >= b.energy:
			ic.modulate = Color(1, 1, 1, 0.22)
		energy_node.add_child(ic)
	row.add_child(energy_node)
	v.add_child(row)
	v.add_child(UI.label("Schild · Energie (jede Karte kostet welche)", 13, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER))
	return p


func _side_panel() -> Control:
	var v := UI.vbox(6)
	v.custom_minimum_size = Vector2(240, 0)
	var piles := UI.hbox(8)
	piles.alignment = BoxContainer.ALIGNMENT_CENTER
	var c1 := UI.chip("cards", str(b.draw_pile.size()), UI.TEXT, 18)
	c1.tooltip_text = "Nachziehstapel"
	c1.mouse_filter = Control.MOUSE_FILTER_PASS
	var c2 := UI.chip("cards", str(b.discard_pile.size()), UI.DIM, 18)
	c2.tooltip_text = "Ablagestapel"
	c2.mouse_filter = Control.MOUSE_FILTER_PASS
	piles.add_child(c1)
	piles.add_child(c2)
	v.add_child(piles)
	if b.state == "won" or b.state == "lost":
		var won: bool = b.state == "won"
		var btn := UI.button("Weiter", _on_continue, Vector2(0, 58), true, 24)
		end_btn = btn
		v.add_child(btn)
	else:
		var btn2 := UI.button("Zug beenden", _on_end_turn, Vector2(0, 58), true, 24)
		btn2.disabled = busy or b.state != "player"
		end_btn = btn2
		var any_playable: bool = false
		for hi in b.hand.size():
			if b.can_play(hi):
				any_playable = true
		if not any_playable and not busy and b.state == "player":
			btn2.ready.connect(func():
				var tw := btn2.create_tween().set_loops()
				tw.tween_property(btn2, "modulate", Color(1.35, 1.25, 1.0), 0.45)
				tw.tween_property(btn2, "modulate", Color.WHITE, 0.45))
		v.add_child(btn2)
	return v


# ================================================================ Eingaben
func _on_select(i: int) -> void:
	selected = i
	Sfx.play("click")
	refresh()


func _on_help() -> void:
	var main: Node = get_parent()
	if main.has_method("show_overlay"):
		main.show_overlay(UI.help_overlay(main.close_overlay))


func _on_card_hover(i: int, on: bool) -> void:
	if gauge == null or not is_instance_valid(gauge):
		return
	if on and i < b.hand.size() and b.state == "player":
		gauge.set_preview(b.heat_delta_of(b.hand[i]))
	else:
		gauge.set_preview(0)


func _unbusy() -> void:
	busy = false
	if end_btn != null and is_instance_valid(end_btn) and b.state == "player":
		end_btn.disabled = false


func _on_continue() -> void:
	finished.emit(b.state)


func _on_card(hand_idx: int) -> void:
	if busy or b.state != "player" or hand_idx >= b.hand.size():
		return
	var id: String = b.hand[hand_idx]
	if tutorial and not _tut_allows_card(id):
		_tut_nudge()
		return
	if not b.can_play(hand_idx):
		Sfx.play("error")
		if hand_idx < card_nodes.size():
			FX.shake(card_nodes[hand_idx], 6.0, 0.25)
		return
	busy = true
	var src: Control = card_nodes[hand_idx] if hand_idx < card_nodes.size() else null
	_fly_card(src, id, selected)
	Sfx.play("card", randf_range(0.95, 1.1))
	b.play_card(hand_idx, selected)
	refresh()
	await get_tree().process_frame
	_consume_events()
	_unbusy()
	if tutorial:
		_tut_on_card_played(id)
	_check_end_state()


func _on_end_turn() -> void:
	if busy or b.state != "player":
		return
	if tutorial and not _tut_allows_end():
		_tut_nudge()
		return
	busy = true
	Sfx.play("turn")
	b.end_turn_begin()
	refresh()
	await get_tree().process_frame
	_consume_events()
	await get_tree().create_timer(0.3).timeout
	while true:
		var i: int = b.enemy_next()
		if i == -1:
			break
		if i < enemy_arts.size():
			await _lunge(enemy_arts[i])
		refresh()
		await get_tree().process_frame
		_consume_events()
		await get_tree().create_timer(0.35).timeout
		if b.state == "lost":
			break
	b.end_turn_finish()
	refresh()
	await get_tree().process_frame
	_consume_events()
	_unbusy()
	if tutorial:
		_tut_on_end_turn()
	_check_end_state()


func _unhandled_key_input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	var k: int = event.keycode
	if k >= KEY_1 and k <= KEY_9:
		_on_card(k - KEY_1)
	elif k == KEY_E or k == KEY_SPACE or k == KEY_ENTER:
		if b.state == "won" or b.state == "lost":
			_on_continue()
		else:
			_on_end_turn()
	elif k == KEY_M:
		Sfx.toggle_all()
	else:
		return
	get_viewport().set_input_as_handled()


# ================================================================ Effekte
func _center(n: Control) -> Vector2:
	if n == null or not is_instance_valid(n):
		return size * 0.5
	return n.global_position + n.size * 0.5


func _lunge(art: Control) -> void:
	if not is_instance_valid(art):
		return
	art.pivot_offset = art.size * 0.5
	var tw := art.create_tween()
	tw.tween_property(art, "scale", Vector2(1.3, 1.3), 0.12).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(art, "scale", Vector2.ONE, 0.12)
	await tw.finished


func _fly_card(src: Control, id: String, tgt: int) -> void:
	if src == null or not is_instance_valid(src):
		return
	var ghost := UI.card(id, 1.0, 0, true, false, Callable(), "", src.size.x / UI.CARD_W)
	UI.ignore_mouse(ghost)
	ghost.z_index = 30
	fx_layer.add_child(ghost)
	ghost.size = src.size
	ghost.global_position = src.global_position
	ghost.pivot_offset = ghost.size * 0.5
	var c: Dictionary = CardDB.CARDS[id]
	var dest: Vector2
	if (c.has("dmg") or c.has("burn")) and tgt >= 0 and tgt < enemy_nodes.size():
		dest = _center(enemy_nodes[tgt]) - ghost.size * 0.5
	else:
		dest = Vector2(size.x * 0.5, size.y * 0.52) - ghost.size * 0.5
	var tw := ghost.create_tween()
	tw.set_parallel(true)
	tw.tween_property(ghost, "global_position", dest, 0.22).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(ghost, "scale", Vector2(0.55, 0.55), 0.22)
	tw.chain().tween_property(ghost, "modulate:a", 0.0, 0.1)
	tw.chain().tween_callback(ghost.queue_free)


func _consume_events() -> void:
	var evs: Array = b.events.duplicate()
	b.events.clear()
	var delay: float = 0.0
	for ev in evs:
		match ev.t:
			"turn":
				pass
			"card":
				if ev.resonance:
					FX.float_text(fx_layer, Vector2(size.x * 0.5, size.y * 0.58), "RESONANZ +2", UI.GOLD, 34)
					Sfx.play("coin", 1.2)
			"edmg":
				_fx_enemy_damage(ev)
			"block":
				FX.float_text(fx_layer, _center(player_node) + Vector2(60, -10), "+%d" % int(ev.v), UI.BLUE, 40)
				Sfx.play("block")
			"heat":
				if int(ev.v) > 0:
					FX.float_text(fx_layer, _center(gauge) + Vector2(randf_range(-80, 80), -20), "+%d Hitze" % int(ev.v), Color(1.0, 0.55, 0.3), 30)
					Sfx.play("heat", 0.8 + 0.5 * float(b.heat) / float(b.heat_limit))
			"cool":
				if int(ev.v) > 0:
					FX.float_text(fx_layer, _center(gauge) + Vector2(randf_range(-80, 80), -20), "−%d Hitze" % int(ev.v), Color(0.6, 0.92, 1.0), 30)
					Sfx.play("cool")
			"melt":
				FX.banner(fx_layer, "KERNSCHMELZE!", Color(1.0, 0.35, 0.15), 0.9)
				FX.flash(fx_layer, Color(1.0, 0.2, 0.0), 0.5, 0.5)
				FX.shake(content, 20.0, 0.5)
				FX.burst(fx_layer, _center(gauge), Color(1.0, 0.5, 0.1), 50, 420.0)
				FX.float_text(fx_layer, _center(player_node) + Vector2(0, -40), "−%d" % int(ev.v), UI.BAD, 56)
				Sfx.play("melt")
			"pdmg":
				if int(ev.v) > 0:
					FX.float_text(fx_layer, _center(player_node) + Vector2(-70, -10), "−%d" % int(ev.v), UI.BAD, 48)
					FX.flash(fx_layer, Color(1, 0.1, 0.1), 0.25, 0.3)
					FX.shake(content, 9.0, 0.3)
					Sfx.play("hurt")
				elif int(ev.blocked) > 0:
					FX.float_text(fx_layer, _center(player_node), "Geblockt", UI.BLUE, 32)
					Sfx.play("block")
			"heal":
				if int(ev.v) > 0:
					FX.float_text(fx_layer, _center(player_node), "+%d" % int(ev.v), UI.GOOD, 44)
			"energy":
				FX.float_text(fx_layer, _center(energy_node), "+%d" % int(ev.v), UI.GOLD, 36)
			"burn":
				if int(ev.i) < enemy_nodes.size():
					FX.float_text(fx_layer, _center(enemy_nodes[int(ev.i)]) + Vector2(0, 30), "Brand +%d" % int(ev.v), UI.GOLD, 28)
			"burntick":
				if int(ev.i) < enemy_nodes.size():
					FX.float_text(fx_layer, _center(enemy_nodes[int(ev.i)]), "−%d" % int(ev.v), Color(1.0, 0.65, 0.2), 38)
					if int(ev.i) < enemy_arts.size():
						enemy_arts[int(ev.i)].hit_flash()
			"eblock":
				if int(ev.i) < enemy_nodes.size():
					FX.float_text(fx_layer, _center(enemy_nodes[int(ev.i)]), "+%d" % int(ev.v), UI.BLUE, 36)
					Sfx.play("block", 0.8)
			"eact":
				pass


func _fx_enemy_damage(ev: Dictionary) -> void:
	var i: int = int(ev.i)
	if i >= enemy_nodes.size():
		return
	var pos: Vector2 = _center(enemy_nodes[i])
	if int(ev.v) > 0:
		var big: bool = int(ev.v) >= 15
		FX.float_text(fx_layer, pos + Vector2(randf_range(-30, 30), -20), "−%d" % int(ev.v), Color(1.0, 0.85, 0.3) if big else Color(1.0, 0.95, 0.9), 64 if big else 46)
		FX.burst(fx_layer, pos, Color(1.0, 0.6, 0.25), 18 if not big else 34)
		FX.shake(enemy_nodes[i], 8.0, 0.25)
		if i < enemy_arts.size():
			enemy_arts[i].hit_flash()
		Sfx.play("hit", randf_range(0.9, 1.1))
	elif int(ev.blocked) > 0:
		FX.float_text(fx_layer, pos, "Geblockt", UI.BLUE, 30)
		Sfx.play("block", 0.7)
	if ev.dead:
		FX.burst(fx_layer, pos, Color(1.0, 0.3, 0.1), 60, 460.0)
		FX.flash(fx_layer, Color(1, 0.9, 0.7), 0.25, 0.3)


func _check_end_state() -> void:
	if ended or (b.state != "won" and b.state != "lost"):
		return
	ended = true
	if b.state == "won":
		Sfx.play("win")
		FX.banner(fx_layer, "SIEG!", UI.GOOD, 1.4)
	else:
		Sfx.play("lose")
		FX.banner(fx_layer, "BESIEGT", UI.BAD, 1.4)
	if tutorial:
		for c in coach_layer.get_children():
			c.queue_free()
		coach_panel = null
		highlight = null


# ================================================================ Tutorial
func _tut_step() -> Dictionary:
	if tut_i >= TUT_STEPS.size():
		return {}
	return TUT_STEPS[tut_i]


func _tut_allows_card(id: String) -> bool:
	var st: Dictionary = _tut_step()
	if st.is_empty() or st.wait == "free":
		return true
	if st.wait.begins_with("play:"):
		return st.wait.split(":")[1] == id
	return false


func _tut_allows_end() -> bool:
	var st: Dictionary = _tut_step()
	return st.is_empty() or st.wait == "end" or st.wait == "free"


func _tut_on_card_played(id: String) -> void:
	var st: Dictionary = _tut_step()
	if not st.is_empty() and st.wait.begins_with("play:"):
		var parts: PackedStringArray = st.wait.split(":")
		if parts[1] == id:
			tut_count += 1
			if tut_count >= int(parts[2]):
				_tut_advance()
				return
	await get_tree().process_frame
	_tut_show()


func _tut_on_end_turn() -> void:
	var st: Dictionary = _tut_step()
	if not st.is_empty() and st.wait == "end":
		_tut_advance()
	else:
		_tut_show()


func _tut_advance() -> void:
	tut_i += 1
	tut_count = 0
	await get_tree().process_frame
	_tut_show()


func _tut_nudge() -> void:
	Sfx.play("error")
	if coach_panel != null and is_instance_valid(coach_panel):
		FX.shake(coach_panel, 8.0, 0.3)


func _tut_target_node(target: String) -> Control:
	if target == "enemy":
		return enemy_nodes[0] if not enemy_nodes.is_empty() else null
	if target == "hand":
		return hand_row
	if target == "gauge":
		return gauge
	if target == "end":
		return end_btn
	if target.begins_with("card:"):
		var id: String = target.substr(5)
		var idx: int = b.hand.find(id)
		if idx >= 0 and idx < card_nodes.size():
			return card_nodes[idx]
		return hand_row
	return null


func _tut_show() -> void:
	for c in coach_layer.get_children():
		c.queue_free()
	coach_panel = null
	highlight = null
	if not tutorial or ended:
		return
	var st: Dictionary = _tut_step()
	if st.is_empty():
		return
	var target: Control = _tut_target_node(st.target)
	# Hervorhebung
	if target != null and is_instance_valid(target):
		highlight = Panel.new()
		highlight.add_theme_stylebox_override("panel", UI.style(Color(1, 0.85, 0.3, 0.07), UI.GOLD, 16, 4, 0))
		highlight.mouse_filter = Control.MOUSE_FILTER_IGNORE
		coach_layer.add_child(highlight)
		var r := Rect2(target.global_position, target.size).grow(8)
		highlight.global_position = r.position
		highlight.size = r.size
		var tw := highlight.create_tween().set_loops()
		tw.tween_property(highlight, "modulate:a", 0.35, 0.5)
		tw.tween_property(highlight, "modulate:a", 1.0, 0.5)
	# Sprechblase
	coach_panel = UI.panel(Color(0.1, 0.08, 0.14, 0.97), 16, UI.GOLD, 3)
	coach_panel.custom_minimum_size = Vector2(460, 0)
	coach_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	var v := UI.vbox(10)
	coach_panel.add_child(v)
	var txt := UI.wrap_label(str(st.text), 22, UI.TEXT)
	txt.custom_minimum_size = Vector2(430, 0)
	v.add_child(txt)
	var row := UI.hbox(10)
	row.add_child(UI.label("Schritt %d / %d" % [tut_i + 1, TUT_STEPS.size()], 14, UI.DIM))
	row.add_child(UI.spacer(false))
	row.add_child(UI.button("Überspringen", func(): finished.emit("skip"), Vector2(130, 36), false, 14))
	if st.wait == "next":
		row.add_child(UI.button("Weiter", _tut_advance, Vector2(120, 40), true, 18))
	v.add_child(row)
	coach_layer.add_child(coach_panel)
	await get_tree().process_frame
	if coach_panel == null or not is_instance_valid(coach_panel):
		return
	# Platzierung: neben dem Gegner bzw. links oben (verdeckt so weder Hand noch Hitze-Leiste)
	var ps: Vector2 = coach_panel.size
	var pos := Vector2(24.0, 84.0)
	if st.target == "enemy" and target != null and is_instance_valid(target):
		pos = Vector2(target.global_position.x + target.size.x + 28.0, target.global_position.y + 20.0)
	elif st.target == "end":
		pos = Vector2(size.x - ps.x - 24.0, size.y * 0.42 - ps.y)
	coach_panel.position = pos
	UI.pop(coach_panel)
