class_name CampScreen
extends Control
## Das Lager: Hier gibst du Schrott aus (Dauerfortschritt) und startest Expeditionen.
## Wenig Text: Symbole, Zahlen und Preise. Erklärungen stehen im Tooltip.

signal start_run(class_id: String)
signal tutorial_requested

const BUILDING_ICONS := {"kuehlturm": "snow", "lazarett": "heart", "funkturm": "bolt"}
const BUILDING_SHORT := {"kuehlturm": "Hitze-Limit +1", "lazarett": "Leben +6", "funkturm": "Karten-Auswahl +1"}

var selected_class: String = "techniker"
var content: Control = null
var confirm_reset: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	refresh()


func refresh() -> void:
	if content != null:
		remove_child(content)
		content.queue_free()
	if not Game.data.unlocked_classes.has(selected_class):
		selected_class = "techniker"
	content = _build()
	add_child(content)


func _build() -> Control:
	var margin := UI.margin_box(20)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var root := UI.vbox(12)
	margin.add_child(root)

	# Kopf
	var head := UI.hbox(10)
	head.add_child(UI.label("GLUTLAGER", 54, UI.EMBER, HORIZONTAL_ALIGNMENT_LEFT, true))
	head.add_child(UI.spacer(false))
	var st: Dictionary = Game.data.stats
	var stats := UI.hbox(8)
	stats.add_child(UI.chip("skull", str(st.best_floor), UI.TEXT, 18))
	stats.add_child(UI.chip("home", str(st.retreats), UI.GOOD, 18))
	stats.get_child(0).tooltip_text = "Beste Etage"
	stats.get_child(1).tooltip_text = "Rückzüge"
	stats.get_child(0).mouse_filter = Control.MOUSE_FILTER_PASS
	stats.get_child(1).mouse_filter = Control.MOUSE_FILTER_PASS
	head.add_child(stats)
	head.add_child(UI.chip("scrap", str(int(Game.data.scrap)), UI.GOLD, 34, UI.PANEL_DARK, 38))
	head.add_child(UI.button("?", _on_help, Vector2(50, 46), false, 24))
	head.add_child(UI.button("Tutorial", func(): tutorial_requested.emit(), Vector2(120, 46), false, 17))
	head.add_child(UI.button("Ton", func(): Sfx.toggle_all(), Vector2(64, 46), false, 16))
	root.add_child(head)

	var cols := UI.hbox(16)
	cols.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cols.add_child(_buildings_panel())
	cols.add_child(_expedition_panel())
	cols.add_child(_workbench_panel())
	root.add_child(cols)

	var foot := UI.hbox()
	var reset_text: String = "Wirklich löschen? Nochmal klicken" if confirm_reset else "Fortschritt zurücksetzen"
	foot.add_child(UI.button(reset_text, _on_reset, Vector2(280, 36), false, 14))
	foot.add_child(UI.spacer(false))
	foot.add_child(UI.button("Beenden", func(): get_tree().quit(), Vector2(140, 36), false, 14))
	root.add_child(foot)
	return margin


func _price_button(cost: int, cb: Callable, min_w: float = 96.0) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(min_w, 46)
	b.focus_mode = Control.FOCUS_NONE
	var can: bool = int(Game.data.scrap) >= cost
	var base: Color = UI.EMBER if can else UI.PANEL
	b.add_theme_stylebox_override("normal", UI.style(base, base.lightened(0.25), 12, 2, 6))
	b.add_theme_stylebox_override("hover", UI.style(base.lightened(0.18), Color(1, 1, 1, 0.5), 12, 2, 6))
	b.add_theme_stylebox_override("pressed", UI.style(base.darkened(0.2), Color(0, 0, 0, 0), 12, 0, 6))
	b.add_theme_stylebox_override("disabled", UI.style(UI.PANEL, Color(1, 1, 1, 0.08), 12, 1, 6))
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var row := UI.icon_row("scrap", str(cost), 24, 22, Color(0.12, 0.06, 0.03) if can else UI.DIM)
	cc.add_child(row)
	b.add_child(cc)
	UI.ignore_mouse(cc)
	b.disabled = not can
	b.pressed.connect(cb)
	return b


# ---------------------------------------------------------------- Gebäude
func _buildings_panel() -> Control:
	var p := UI.panel(UI.PANEL, 14, Color(1, 1, 1, 0.06), 1)
	p.custom_minimum_size = Vector2(330, 0)
	var v := UI.vbox(10)
	p.add_child(v)
	v.add_child(UI.label("Lager", 26, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true))
	for id in Game.BUILDINGS:
		var def: Dictionary = Game.BUILDINGS[id]
		var lvl: int = Game.building_level(id)
		var max_lvl: int = def.costs.size()
		var box := UI.panel(UI.PANEL_LIGHT, 10)
		box.tooltip_text = "%s: %s" % [def.name, def.desc]
		var row := UI.hbox(12)
		box.add_child(row)
		var ic := PanelContainer.new()
		ic.add_theme_stylebox_override("panel", UI.style(UI.PANEL_DARK, GIcon.default_color(BUILDING_ICONS[id]).darkened(0.3), 30, 2, 8))
		ic.add_child(GIcon.make(BUILDING_ICONS[id], 36, GIcon.default_color(BUILDING_ICONS[id])))
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(ic)
		var col := UI.vbox(3)
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_child(UI.label(str(def.name), 19, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true))
		col.add_child(UI.label(BUILDING_SHORT[id], 13, UI.DIM))
		var pips := UI.hbox(4)
		for k in max_lvl:
			var pip := ColorRect.new()
			pip.custom_minimum_size = Vector2(22, 8)
			pip.color = UI.EMBER if k < lvl else Color(1, 1, 1, 0.12)
			pip.mouse_filter = Control.MOUSE_FILTER_IGNORE
			pips.add_child(pip)
		col.add_child(pips)
		row.add_child(col)
		var cost: int = Game.building_next_cost(id)
		if cost < 0:
			row.add_child(UI.label("MAX", 18, UI.GOOD, HORIZONTAL_ALIGNMENT_CENTER, true))
		else:
			row.add_child(_price_button(cost, _on_buy_building.bind(id)))
		v.add_child(box)
	v.add_child(UI.spacer())
	return p


# ---------------------------------------------------------------- Expedition
func _expedition_panel() -> Control:
	var p := UI.panel(UI.PANEL, 14, Color(1, 1, 1, 0.06), 1)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := UI.vbox(10)
	p.add_child(v)
	v.add_child(CampfireArt.new())
	var heroes := UI.hbox(12)
	heroes.alignment = BoxContainer.ALIGNMENT_CENTER
	heroes.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for id in HeroDB.CLASSES:
		heroes.add_child(_hero_tile(id))
	v.add_child(heroes)
	var go := UI.button("EXPEDITION STARTEN", func(): start_run.emit(selected_class), Vector2(0, 72), true, 30)
	v.add_child(go)
	return p


func _hero_tile(id: String) -> Control:
	var cls: Dictionary = HeroDB.CLASSES[id]
	var unlocked: bool = Game.data.unlocked_classes.has(id)
	var is_sel: bool = unlocked and id == selected_class
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(210, 0)
	btn.size_flags_vertical = Control.SIZE_EXPAND_FILL
	btn.focus_mode = Control.FOCUS_NONE
	btn.tooltip_text = str(cls.desc)
	var border: Color = UI.EMBER if is_sel else Color(1, 1, 1, 0.1)
	btn.add_theme_stylebox_override("normal", UI.style(UI.PANEL_LIGHT, border, 16, 4 if is_sel else 1, 0))
	btn.add_theme_stylebox_override("hover", UI.style(UI.PANEL_LIGHT.lightened(0.1), UI.EMBER.darkened(0.2), 16, 3, 0))
	btn.add_theme_stylebox_override("pressed", UI.style(UI.PANEL_LIGHT, UI.EMBER, 16, 4, 0))
	btn.pressed.connect(_on_class.bind(id))
	var m := UI.margin_box(10)
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := UI.vbox(6)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	m.add_child(v)
	var emblem: String = "gear" if id == "techniker" else "flame"
	var big := GIcon.make(emblem if unlocked else "lock", 58, GIcon.default_color(emblem) if unlocked else UI.DIM)
	big.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(big)
	v.add_child(UI.label(str(cls.name), 24, UI.TEXT if unlocked else UI.DIM, HORIZONTAL_ALIGNMENT_CENTER, true))
	if unlocked:
		var st := UI.vbox(2)
		var hp: int = int(cls.hp) + 6 * Game.building_level("lazarett")
		var lim: int = int(cls.heat_limit) + Game.building_level("kuehlturm")
		var rows: Array = [["heart", str(hp)], ["heat", str(lim)], ["snow", str(cls.cooling)]]
		for r in rows:
			var line := UI.icon_row(r[0], r[1], 22, 20, UI.TEXT)
			var wrap := CenterContainer.new()
			wrap.add_child(line)
			st.add_child(wrap)
		v.add_child(st)
	else:
		var cc := CenterContainer.new()
		cc.add_child(UI.chip("scrap", str(int(cls.unlock)), UI.GOLD, 20))
		v.add_child(cc)
	btn.add_child(m)
	UI.ignore_mouse(m)
	return btn


# ---------------------------------------------------------------- Werkbank
func _workbench_panel() -> Control:
	var p := UI.panel(UI.PANEL, 14, Color(1, 1, 1, 0.06), 1)
	p.custom_minimum_size = Vector2(400, 0)
	var v := UI.vbox(8)
	p.add_child(v)
	var head := UI.hbox()
	head.add_child(UI.label("Werkbank", 26, UI.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true))
	head.add_child(UI.spacer(false))
	head.add_child(UI.chip("cards", "%d/%d" % [Game.data.unlocked_cards.size(), CardDB.CARDS.size()], UI.DIM, 18))
	v.add_child(head)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 10)
	sc.add_child(grid)
	var f: float = 0.72
	for id in CardDB.unlockable_ids():
		if Game.data.unlocked_cards.has(id):
			continue
		var cell := UI.vbox(4)
		var cost: int = int(CardDB.CARDS[id].unlock)
		var card := UI.card(id, 1.0, 0, false, false, _on_buy_card.bind(id), "", f)
		card.modulate = Color(1, 1, 1, 0.8 if int(Game.data.scrap) >= cost else 0.45)
		cell.add_child(card)
		cell.add_child(_price_button(cost, _on_buy_card.bind(id), 0.0))
		grid.add_child(cell)
	var owned_label := UI.label("Freigeschaltet", 16, UI.DIM)
	var any_locked: bool = grid.get_child_count() > 0
	if not any_locked:
		grid.add_child(UI.label("Alles freigeschaltet!", 20, UI.GOOD))
	return p


# ---------------------------------------------------------------- Aktionen
func _on_help() -> void:
	var main: Node = get_parent()
	if main.has_method("show_overlay"):
		main.show_overlay(UI.help_overlay(main.close_overlay))


func _on_buy_building(id: String) -> void:
	if Game.buy_building(id):
		Sfx.play("buy")
	refresh()


func _on_buy_card(id: String) -> void:
	if Game.buy_card(id):
		Sfx.play("buy")
	else:
		Sfx.play("error")
	refresh()


func _on_class(id: String) -> void:
	if Game.data.unlocked_classes.has(id):
		selected_class = id
	elif Game.buy_class(id):
		Sfx.play("buy")
		selected_class = id
	else:
		Sfx.play("error")
	refresh()


func _on_reset() -> void:
	if confirm_reset:
		Game.reset_progress()
		confirm_reset = false
		selected_class = "techniker"
	else:
		confirm_reset = true
	refresh()
