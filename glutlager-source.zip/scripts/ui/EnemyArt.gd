class_name EnemyArt
extends Control
## Gegner-Bilder, per Code gezeichnet und leicht animiert (Atmen, Leuchten).

var enemy_id: String = "ratte"
var t: float = 0.0
var flash: float = 0.0  # 1.0 = kurz weiß aufleuchten (Treffer)


static func make(id: String, px: int = 150) -> EnemyArt:
	var e := EnemyArt.new()
	e.enemy_id = id
	e.custom_minimum_size = Vector2(px, px)
	e.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	e.mouse_filter = Control.MOUSE_FILTER_IGNORE
	e.t = randf() * 6.0
	return e


func hit_flash() -> void:
	flash = 1.0


func _process(delta: float) -> void:
	t += delta
	flash = maxf(0.0, flash - delta * 4.0)
	queue_redraw()


func _p(x: float, y: float) -> Vector2:
	return Vector2(x, y) * size


func _poly(pts: Array, col: Color) -> void:
	var arr := PackedVector2Array()
	for q in pts:
		arr.append(_p(q[0], q[1]))
	draw_colored_polygon(arr, _tint(col))


func _tint(col: Color) -> Color:
	return col.lerp(Color.WHITE, flash * 0.8)


func _ell(cx: float, cy: float, rx: float, ry: float, col: Color) -> void:
	var pts := PackedVector2Array()
	for k in 28:
		var a: float = k * TAU / 28.0
		pts.append(_p(cx + cos(a) * rx, cy + sin(a) * ry))
	draw_colored_polygon(pts, _tint(col))


func _eye(x: float, y: float, r: float, col: Color) -> void:
	var glow: float = 0.7 + 0.3 * sin(t * 4.0)
	draw_circle(_p(x, y), size.x * r * 2.2, Color(col.r, col.g, col.b, 0.25 * glow))
	draw_circle(_p(x, y), size.x * r, col.lerp(Color.WHITE, 0.3))


func _draw() -> void:
	var s: float = size.x
	var bob: float = sin(t * 2.2) * 0.015
	draw_set_transform(Vector2(0, bob * s), 0.0, Vector2.ONE)
	# Schatten
	draw_circle(_p(0.5, 0.93), s * 0.0, Color(0, 0, 0, 0))
	_ell(0.5, 0.93, 0.3, 0.04, Color(0, 0, 0, 0.35))
	match enemy_id:
		"ratte":
			draw_polyline(PackedVector2Array([_p(0.28, 0.7), _p(0.15, 0.62), _p(0.1, 0.5), _p(0.16, 0.4)]), _tint(Color(0.85, 0.6, 0.6)), s * 0.03, true)
			_ell(0.46, 0.66, 0.3, 0.2, Color(0.45, 0.4, 0.42))
			_ell(0.74, 0.58, 0.14, 0.11, Color(0.52, 0.46, 0.48))
			_ell(0.70, 0.45, 0.05, 0.06, Color(0.9, 0.6, 0.65))
			_ell(0.79, 0.46, 0.05, 0.06, Color(0.9, 0.6, 0.65))
			_poly([[0.84, 0.58], [0.96, 0.62], [0.84, 0.66]], Color(0.6, 0.5, 0.52))
			_eye(0.78, 0.56, 0.022, Color(1.0, 0.25, 0.2))
			for k in 3:
				draw_line(_p(0.3 + 0.12 * k, 0.8), _p(0.28 + 0.12 * k, 0.9), _tint(Color(0.35, 0.3, 0.32)), s * 0.035, true)
		"wolf":
			_ell(0.45, 0.62, 0.3, 0.2, Color(0.55, 0.3, 0.2))
			_poly([[0.62, 0.48], [0.82, 0.42], [0.96, 0.58], [0.84, 0.68], [0.64, 0.66]], Color(0.62, 0.35, 0.22))
			_poly([[0.64, 0.46], [0.66, 0.26], [0.74, 0.42]], Color(0.5, 0.26, 0.18))
			_poly([[0.76, 0.42], [0.82, 0.24], [0.86, 0.46]], Color(0.5, 0.26, 0.18))
			for k in 4:
				_poly([[0.25 + 0.08 * k, 0.46], [0.29 + 0.08 * k, 0.32], [0.33 + 0.08 * k, 0.46]], Color(0.78, 0.45, 0.2))
			_eye(0.78, 0.53, 0.024, Color(1.0, 0.6, 0.15))
			draw_line(_p(0.2, 0.7), _p(0.08, 0.6), _tint(Color(0.5, 0.28, 0.2)), s * 0.05, true)
			for k in 4:
				draw_line(_p(0.28 + 0.14 * k, 0.76), _p(0.28 + 0.14 * k, 0.9), _tint(Color(0.4, 0.22, 0.16)), s * 0.045, true)
		"drohne":
			var spin: float = cos(t * 30.0)
			draw_line(_p(0.5 - 0.3 * absf(spin) - 0.02, 0.28), _p(0.5 + 0.3 * absf(spin) + 0.02, 0.28), _tint(Color(0.7, 0.8, 0.9, 0.7)), s * 0.025, true)
			draw_line(_p(0.5, 0.28), _p(0.5, 0.4), _tint(Color(0.45, 0.5, 0.6)), s * 0.03, true)
			_ell(0.5, 0.56, 0.24, 0.2, Color(0.4, 0.46, 0.56))
			_ell(0.5, 0.6, 0.2, 0.12, Color(0.3, 0.35, 0.45))
			_eye(0.5, 0.55, 0.07, Color(0.3, 0.9, 1.0))
			for sgn in [-1.0, 1.0]:
				draw_line(_p(0.5 + 0.2 * sgn, 0.66), _p(0.5 + 0.3 * sgn, 0.8), _tint(Color(0.45, 0.5, 0.6)), s * 0.03, true)
			if int(t * 6.0) % 3 == 0:
				draw_line(_p(0.28, 0.5), _p(0.2, 0.44), Color(0.5, 0.95, 1.0), s * 0.02, true)
				draw_line(_p(0.2, 0.44), _p(0.24, 0.38), Color(0.5, 0.95, 1.0), s * 0.02, true)
		"pluenderer":
			_poly([[0.5, 0.1], [0.7, 0.28], [0.84, 0.92], [0.16, 0.92], [0.3, 0.28]], Color(0.28, 0.22, 0.3))
			_poly([[0.5, 0.1], [0.62, 0.22], [0.5, 0.5], [0.38, 0.22]], Color(0.16, 0.12, 0.2))
			_ell(0.5, 0.31, 0.11, 0.1, Color(0.08, 0.06, 0.1))
			_eye(0.45, 0.31, 0.02, Color(1.0, 0.8, 0.2))
			_eye(0.55, 0.31, 0.02, Color(1.0, 0.8, 0.2))
			_ell(0.3, 0.42, 0.1, 0.06, Color(0.4, 0.34, 0.4))
			draw_line(_p(0.88, 0.25), _p(0.72, 0.82), _tint(Color(0.6, 0.6, 0.65)), s * 0.035, true)
			draw_line(_p(0.88, 0.25), _p(0.94, 0.18), _tint(Color(0.9, 0.9, 0.95)), s * 0.05, true)
		"golem":
			draw_rect(Rect2(_p(0.3, 0.32), Vector2(0.4, 0.45) * s), _tint(Color(0.38, 0.4, 0.46)))
			draw_rect(Rect2(_p(0.41, 0.12), Vector2(0.18, 0.18) * s), _tint(Color(0.45, 0.47, 0.54)))
			draw_rect(Rect2(_p(0.12, 0.34), Vector2(0.17, 0.4) * s), _tint(Color(0.33, 0.35, 0.4)))
			draw_rect(Rect2(_p(0.71, 0.34), Vector2(0.17, 0.4) * s), _tint(Color(0.33, 0.35, 0.4)))
			draw_rect(Rect2(_p(0.32, 0.77), Vector2(0.14, 0.16) * s), _tint(Color(0.3, 0.32, 0.37)))
			draw_rect(Rect2(_p(0.54, 0.77), Vector2(0.14, 0.16) * s), _tint(Color(0.3, 0.32, 0.37)))
			var pulse: float = 0.6 + 0.4 * sin(t * 3.0)
			draw_circle(_p(0.5, 0.52), s * 0.13, Color(1.0, 0.5, 0.15, 0.3 * pulse))
			draw_circle(_p(0.5, 0.52), s * 0.07, Color(1.0, 0.7, 0.3))
			_eye(0.46, 0.2, 0.02, Color(1.0, 0.55, 0.2))
			_eye(0.54, 0.2, 0.02, Color(1.0, 0.55, 0.2))
			draw_polyline(PackedVector2Array([_p(0.34, 0.34), _p(0.4, 0.42), _p(0.36, 0.5)]), Color(0.15, 0.15, 0.2), s * 0.015)
		"glutkern":
			var pulse2: float = 0.8 + 0.2 * sin(t * 2.5)
			draw_circle(_p(0.5, 0.5), s * 0.5 * pulse2, Color(1.0, 0.3, 0.05, 0.12))
			draw_circle(_p(0.5, 0.5), s * 0.4 * pulse2, Color(1.0, 0.4, 0.1, 0.2))
			for k in 12:
				var a: float = t * 0.6 + k * TAU / 12.0
				var d := Vector2(cos(a), sin(a))
				var len_in: float = 0.3
				var len_out: float = 0.42 + 0.04 * sin(t * 3.0 + k)
				draw_line(size * 0.5 + d * s * len_in, size * 0.5 + d * s * len_out, _tint(Color(1.0, 0.45, 0.1)), s * 0.035, true)
			draw_circle(_p(0.5, 0.5), s * 0.28, _tint(Color(0.85, 0.25, 0.05)))
			draw_circle(_p(0.5, 0.5), s * 0.2, _tint(Color(1.0, 0.55, 0.12)))
			draw_circle(_p(0.5, 0.5), s * 0.11, _tint(Color(1.0, 0.9, 0.55)))
			_eye(0.5, 0.5, 0.04, Color(1.0, 1.0, 1.0))
		"puppe":
			draw_line(_p(0.5, 0.35), _p(0.5, 0.92), _tint(Color(0.55, 0.38, 0.22)), s * 0.07, true)
			draw_line(_p(0.25, 0.46), _p(0.75, 0.46), _tint(Color(0.55, 0.38, 0.22)), s * 0.06, true)
			_ell(0.5, 0.26, 0.13, 0.13, Color(0.78, 0.6, 0.38))
			draw_circle(_p(0.5, 0.62), s * 0.15, _tint(Color(0.9, 0.9, 0.9)))
			draw_circle(_p(0.5, 0.62), s * 0.1, _tint(Color(0.9, 0.25, 0.25)))
			draw_circle(_p(0.5, 0.62), s * 0.04, _tint(Color(0.9, 0.9, 0.9)))
		_:
			draw_circle(_p(0.5, 0.5), s * 0.3, _tint(Color(0.5, 0.5, 0.5)))
