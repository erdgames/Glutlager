class_name UI
extends RefCounted
## Bausteine für die Oberfläche (Texte, Knöpfe, Chips, Karten).
## Grundregel: Symbole + Zahlen statt Sätze. Erklärungen stehen nur im Tutorial
## und als Tooltip (kurz mit der Maus verweilen).

const BG := Color(0.078, 0.067, 0.102)
const PANEL := Color(0.137, 0.118, 0.169)
const PANEL_LIGHT := Color(0.19, 0.16, 0.23)
const PANEL_DARK := Color(0.09, 0.08, 0.12)
const EMBER := Color(1.0, 0.48, 0.2)
const GOLD := Color(0.98, 0.80, 0.32)
const TEXT := Color(0.95, 0.92, 0.96)
const DIM := Color(0.66, 0.62, 0.72)
const GOOD := Color(0.44, 0.85, 0.52)
const BAD := Color(0.95, 0.38, 0.38)
const BLUE := Color(0.40, 0.76, 0.98)

const CARD_W := 150.0
const CARD_H := 228.0

static var _bold: FontVariation = null


static func bold_font() -> Font:
	if _bold == null:
		_bold = FontVariation.new()
		_bold.base_font = ThemeDB.fallback_font
		_bold.variation_embolden = 0.55
	return _bold


static func style(bg: Color, border: Color = Color(0, 0, 0, 0), radius: int = 10, bw: int = 0, margin: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	if bw > 0:
		s.border_color = border
		s.set_border_width_all(bw)
	s.set_content_margin_all(margin)
	return s


static func label(text: String, size: int = 18, color: Color = TEXT, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, bold: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = align
	if bold:
		l.add_theme_font_override("font", bold_font())
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.55))
		l.add_theme_constant_override("outline_size", maxi(2, size / 8))
	return l


static func wrap_label(text: String, size: int = 16, color: Color = TEXT) -> Label:
	var l := label(text, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


static func title(text: String, size: int = 40, color: Color = EMBER) -> Label:
	return label(text, size, color, HORIZONTAL_ALIGNMENT_CENTER, true)


static func button(text: String, cb: Callable, min_size: Vector2 = Vector2(0, 46), accent: bool = false, font_size: int = 18) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_font_override("font", bold_font())
	var base: Color = EMBER if accent else PANEL_LIGHT
	var fg: Color = Color(0.12, 0.06, 0.03) if accent else TEXT
	b.add_theme_stylebox_override("normal", style(base, base.lightened(0.25), 12, 2, 10))
	b.add_theme_stylebox_override("hover", style(base.lightened(0.16), Color(1, 1, 1, 0.5), 12, 2, 10))
	b.add_theme_stylebox_override("pressed", style(base.darkened(0.2), Color(0, 0, 0, 0), 12, 0, 10))
	b.add_theme_stylebox_override("disabled", style(PANEL, Color(1, 1, 1, 0.05), 12, 1, 10))
	b.add_theme_color_override("font_color", fg)
	b.add_theme_color_override("font_hover_color", fg)
	b.add_theme_color_override("font_pressed_color", fg)
	b.add_theme_color_override("font_disabled_color", DIM)
	if cb.is_valid():
		b.pressed.connect(cb)
		b.pressed.connect(func(): Sfx.play("click"))
	return b


static func panel(bg: Color = PANEL, margin: int = 14, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(bg, border, 14, bw, margin))
	return p


static func vbox(sep: int = 8) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	return v


static func hbox(sep: int = 8) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	return h


static func spacer(vertical: bool = true) -> Control:
	var c := Control.new()
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if vertical:
		c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	else:
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return c


static func ignore_mouse(n: Node) -> void:
	if n is Control:
		n.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for c in n.get_children():
		ignore_mouse(c)


static func margin_box(m: int = 16) -> MarginContainer:
	var mc := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		mc.add_theme_constant_override("margin_" + side, m)
	return mc


## Symbol + Zahl in einer Zeile
static func icon_row(kind: String, text: String, icon_px: int = 26, font_size: int = 22, color: Color = TEXT, gap: int = 5) -> HBoxContainer:
	var h := hbox(gap)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(GIcon.make(kind, icon_px, GIcon.default_color(kind)))
	var l := label(text, font_size, color, HORIZONTAL_ALIGNMENT_LEFT, true)
	l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(l)
	return h


## Kleine Pille (z. B. "[Schrott-Symbol] 25")
static func chip(kind: String, text: String, color: Color = TEXT, font_size: int = 20, bg: Color = PANEL_DARK, icon_px: int = 24) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(bg, Color(1, 1, 1, 0.1), 20, 1, 6))
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var row := icon_row(kind, text, icon_px, font_size, color)
	var m := margin_box(0)
	m.add_theme_constant_override("margin_left", 6)
	m.add_theme_constant_override("margin_right", 8)
	m.add_child(row)
	p.add_child(m)
	return p


## Balken mit Text (Leben ...)
static func bar(value: float, max_value: float, color: Color, text: String, size: Vector2 = Vector2(220, 24)) -> Control:
	var pb := ProgressBar.new()
	pb.custom_minimum_size = size
	pb.max_value = maxf(1.0, max_value)
	pb.value = clampf(value, 0.0, max_value)
	pb.show_percentage = false
	pb.add_theme_stylebox_override("background", style(Color(0.07, 0.06, 0.09), Color(1, 1, 1, 0.1), 8, 1, 0))
	pb.add_theme_stylebox_override("fill", style(color, color.lightened(0.3), 8, 1, 0))
	var l := label(text, 15, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	pb.add_child(l)
	return pb


static func tag_art_icon(tag: String) -> String:
	match tag:
		"feuer": return "flame"
		"funk": return "bolt"
		_: return "gear"


## Effekt-Zeilen einer Karte: [[symbol, text, farbe], ...]. m = Hitze-Faktor, bonus = Resonanz.
static func card_rows(id: String, m: float, bonus: int) -> Array:
	var c: Dictionary = CardDB.CARDS[id]
	var rows: Array = []
	var sp: String = c.get("special", "")
	var dmg: int = c.get("dmg", 0)
	var blk: int = c.get("blk", 0)
	var hits: int = c.get("hits", 1)
	var d_bonus: int = bonus if dmg > 0 else 0
	var b_bonus: int = bonus if (dmg == 0 and blk > 0) else 0
	if sp == "heat_dump":
		rows.append(["sword", "3×Hitze Schaden", TEXT])
	elif sp == "per_card":
		var v: int = floori((dmg + d_bonus) * m)
		rows.append(["sword", "%d+ Schaden" % v, GOLD if v > dmg else TEXT])
	elif dmg > 0:
		var v2: int = floori((dmg + d_bonus) * m)
		var txt: String = str(v2) + ("×%d" % hits if hits > 1 else "") + " Schaden"
		rows.append(["sword", txt, GOLD if v2 > dmg else TEXT])
	if blk > 0:
		var v3: int = floori((blk + b_bonus) * m)
		rows.append(["shield", "%d Schild" % v3, GOLD if v3 > blk else TEXT])
	if c.has("burn"):
		rows.append(["burn", "%d Brand" % int(c.burn), TEXT])
	if c.has("cool"):
		rows.append(["snow", "Kühlt %d" % int(c.cool), BLUE])
	if c.has("draw"):
		rows.append(["cards", "+%d Karten" % int(c.draw), TEXT])
	if c.has("energy"):
		rows.append(["energy", "+%d Energie" % int(c.energy), GOLD])
	if c.has("heal"):
		rows.append(["heart", "+%d Leben" % int(c.heal), GOOD])
	if sp == "hot_runner":
		rows.append(["energy", "+1 Energie/Zug", GOLD])
	if c.has("heat"):
		rows.append(["heat", "+%d Hitze" % int(c.heat), Color(1.0, 0.5, 0.3)])
	return rows


## Eine Karte als Knopf. warn = "würde Kernschmelze auslösen". f = Größenfaktor.
static func card(id: String, m: float = 1.0, bonus: int = 0, enabled: bool = true, warn: bool = false, on_click: Callable = Callable(), hotkey: String = "", f: float = 1.0) -> Button:
	var c: Dictionary = CardDB.CARDS[id]
	var tagc: Color = CardDB.tag_color(id)
	var b := Button.new()
	var w: float = CARD_W * f
	var h: float = CARD_H * f
	b.custom_minimum_size = Vector2(w, h)
	b.focus_mode = Control.FOCUS_NONE
	b.tooltip_text = CardDB.describe(id)
	var border: Color = BAD if warn else (GOLD if bonus > 0 else tagc)
	var bw: int = 4 if (warn or bonus > 0) else 3
	var bg: Color = Color(0.17, 0.14, 0.21)
	b.add_theme_stylebox_override("normal", style(bg, border, 14, bw, 0))
	b.add_theme_stylebox_override("hover", style(bg.lightened(0.1), border.lightened(0.35), 14, bw + 1, 0))
	b.add_theme_stylebox_override("pressed", style(bg.darkened(0.1), border, 14, bw, 0))
	b.add_theme_stylebox_override("disabled", style(PANEL, border.darkened(0.5), 14, bw, 0))
	if not enabled:
		b.modulate = Color(1, 1, 1, 0.45)

	var margin := margin_box(int(8 * f))
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := vbox(int(4 * f))
	margin.add_child(v)

	# Kopf: Kosten + Name
	var top := hbox(6)
	var gem := PanelContainer.new()
	gem.add_theme_stylebox_override("panel", style(tagc.darkened(0.45), tagc.lightened(0.2), 20, 2, 2))
	var cost_l := label(str(int(c.cost)), int(20 * f), Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, true)
	cost_l.custom_minimum_size = Vector2(22 * f, 0)
	gem.add_child(cost_l)
	top.add_child(gem)
	var name_size: int = int((15 if str(c.name).length() <= 11 else (13 if str(c.name).length() <= 13 else 12)) * f)
	var name_l := label(str(c.name), name_size, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, true)
	name_l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	top.add_child(name_l)
	v.add_child(top)

	# Bildfläche mit Tag-Symbol
	var art := PanelContainer.new()
	art.add_theme_stylebox_override("panel", style(tagc.darkened(0.7), tagc.darkened(0.3), 10, 1, 2))
	art.custom_minimum_size = Vector2(0, 30 * f)
	art.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var cc := CenterContainer.new()
	var art_row := hbox(10)
	art_row.add_child(GIcon.make(tag_art_icon(c.tag), int(24 * f), tagc))
	cc.add_child(art_row)
	art.add_child(cc)
	v.add_child(art)

	# Effekte
	var rows := vbox(int(1 * f))
	rows.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var crow: Array = card_rows(id, m, bonus)
	var big: bool = crow.size() <= 2
	for r in crow:
		rows.add_child(icon_row(r[0], r[1], int((26 if big else 22) * f), int((19 if big else 16) * f), r[2]))
	v.add_child(rows)

	# Fuß: Hinweis / Warnung
	var foot_text: String = CardDB.footnote(id)
	var foot_col: Color = DIM
	if warn:
		foot_text = "KERNSCHMELZE!"
		foot_col = BAD
	elif bonus > 0:
		foot_text = "Resonanz +%d" % bonus
		foot_col = GOLD
	var foot := label(foot_text, int(12 * f), foot_col, HORIZONTAL_ALIGNMENT_CENTER, warn or bonus > 0)
	foot.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	foot.custom_minimum_size = Vector2(0, 30 * f)
	v.add_child(foot)

	b.add_child(margin)
	ignore_mouse(margin)

	b.pivot_offset = Vector2(w / 2.0, h / 2.0)
	b.mouse_entered.connect(func(): _hover(b, true))
	b.mouse_exited.connect(func(): _hover(b, false))
	if on_click.is_valid():
		b.pressed.connect(on_click)
	return b


static func _hover(b: Control, on: bool) -> void:
	if not is_instance_valid(b) or not b.is_inside_tree():
		return
	var t := b.create_tween()
	t.tween_property(b, "scale", Vector2.ONE * (1.08 if on else 1.0), 0.08)
	b.z_index = 5 if on else 0


static func fade_in(n: Control, t: float = 0.22) -> void:
	n.modulate.a = 0.0
	var tw := n.create_tween()
	tw.tween_property(n, "modulate:a", 1.0, t)


static func pop(n: Control) -> void:
	n.pivot_offset = n.size * 0.5
	n.scale = Vector2(0.85, 0.85)
	var tw := n.create_tween()
	tw.tween_property(n, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## Vollbild-Overlay mit allen Karten eines Decks. on_pick(index) ist optional.
static func deck_overlay(deck: Array, title_text: String, on_pick: Callable, on_close: Callable) -> Control:
	var root := ColorRect.new()
	root.color = Color(0, 0, 0, 0.8)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var m := margin_box(36)
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(m)
	var p := panel(PANEL, 18)
	m.add_child(p)
	var v := vbox(12)
	p.add_child(v)
	var head := hbox()
	head.add_child(label(title_text, 28, EMBER, HORIZONTAL_ALIGNMENT_LEFT, true))
	head.add_child(spacer(false))
	head.add_child(button("Schließen", on_close, Vector2(150, 44)))
	v.add_child(head)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(sc)
	var grid := GridContainer.new()
	grid.columns = 7
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	sc.add_child(grid)
	for i in deck.size():
		var cb: Callable = on_pick.bind(i) if on_pick.is_valid() else Callable()
		grid.add_child(card(deck[i], 1.0, 0, true, false, cb, "", 0.85))
	return root


## Hilfe-Übersicht: alle Symbole in einem Blick
static func help_overlay(on_close: Callable) -> Control:
	var root := ColorRect.new()
	root.color = Color(0, 0, 0, 0.82)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(cc)
	var p := panel(PANEL, 26, EMBER.darkened(0.3), 2)
	cc.add_child(p)
	var v := vbox(12)
	p.add_child(v)
	v.add_child(title("Kurz erklärt", 36))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 40)
	grid.add_theme_constant_override("v_separation", 10)
	v.add_child(grid)
	var items: Array = [
		["sword", "Schaden"], ["shield", "Schild (hält Schaden ab)"],
		["heat", "Hitze: mehr = stärker, aber…"], ["skull", "…zu viel = Kernschmelze!"],
		["snow", "Kühlen: senkt die Hitze"], ["energy", "Energie: 3 pro Zug"],
		["cards", "Karten ziehen"], ["burn", "Brand: Schaden jede Runde"],
	]
	for it in items:
		grid.add_child(icon_row(it[0], it[1], 30, 20))
	var res := hbox(8)
	res.alignment = BoxContainer.ALIGNMENT_CENTER
	res.add_child(GIcon.make("flame", 26))
	res.add_child(GIcon.make("flame", 26))
	res.add_child(label("Gleiches Symbol hintereinander = Resonanz +2", 20, GOLD, HORIZONTAL_ALIGNMENT_LEFT, true))
	v.add_child(res)
	var btn := button("Verstanden", on_close, Vector2(240, 50), true, 20)
	btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(btn)
	return root
