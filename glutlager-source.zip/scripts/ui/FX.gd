class_name FX
extends RefCounted
## Kleine Effekte: schwebende Zahlen, Wackeln, Blitze, Funken.

static func float_text(parent: Control, pos: Vector2, text: String, color: Color, font_size: int = 40) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 8)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.z_index = 50
	parent.add_child(l)
	l.reset_size()
	l.position = pos - l.size * 0.5
	l.pivot_offset = l.size * 0.5
	l.scale = Vector2(0.4, 0.4)
	var tw := l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "scale", Vector2(1.25, 1.25), 0.14).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "position:y", l.position.y - 80.0, 0.9).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.chain().tween_property(l, "modulate:a", 0.0, 0.35)
	tw.chain().tween_callback(l.queue_free)


static func shake(node: Control, strength: float = 10.0, dur: float = 0.3) -> void:
	if not is_instance_valid(node):
		return
	var origin: Vector2 = node.position
	var tw := node.create_tween()
	var steps: int = 7
	for i in steps:
		var fade: float = 1.0 - float(i) / float(steps)
		var off := Vector2(randf_range(-1, 1), randf_range(-1, 1)) * strength * fade
		tw.tween_property(node, "position", origin + off, dur / float(steps))
	tw.tween_property(node, "position", origin, 0.03)


static func flash(parent: Control, color: Color, alpha: float = 0.35, dur: float = 0.35) -> void:
	var r := ColorRect.new()
	r.color = Color(color.r, color.g, color.b, alpha)
	r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.z_index = 40
	parent.add_child(r)
	var tw := r.create_tween()
	tw.tween_property(r, "color:a", 0.0, dur)
	tw.tween_callback(r.queue_free)


static func burst(parent: Node, pos: Vector2, color: Color, amount: int = 26, speed: float = 280.0) -> void:
	var p := CPUParticles2D.new()
	p.position = pos
	p.amount = amount
	p.one_shot = true
	p.explosiveness = 1.0
	p.lifetime = 0.7
	p.direction = Vector2(0, -1)
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector2(0, 520)
	p.scale_amount_min = 3.0
	p.scale_amount_max = 7.0
	var g := Gradient.new()
	g.colors = PackedColorArray([color.lightened(0.3), Color(color.r, color.g, color.b, 0.0)])
	p.color_ramp = g
	p.z_index = 45
	parent.add_child(p)
	p.emitting = true
	var timer := p.get_tree().create_timer(1.2)
	timer.timeout.connect(p.queue_free)


static func banner(parent: Control, text: String, color: Color, dur: float = 1.1) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 84)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.95))
	l.add_theme_constant_override("outline_size", 14)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.z_index = 60
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(l)
	l.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	l.grow_horizontal = Control.GROW_DIRECTION_BOTH
	l.grow_vertical = Control.GROW_DIRECTION_BOTH
	l.pivot_offset = l.size * 0.5
	l.scale = Vector2(2.2, 2.2)
	l.modulate.a = 0.0
	var tw := l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 1.0, 0.12)
	tw.chain().tween_interval(dur)
	tw.chain().tween_property(l, "modulate:a", 0.0, 0.3)
	tw.chain().tween_callback(l.queue_free)
