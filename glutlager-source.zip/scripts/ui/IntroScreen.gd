class_name IntroScreen
extends Control
## Drei kurze Folien, die die Spielidee in Bildern erklären (vor dem Übungskampf).

signal done

var slide: int = 0
var content: Control = null
var t: float = 0.0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	refresh()


func _process(delta: float) -> void:
	t += delta


func refresh() -> void:
	if content != null:
		remove_child(content)
		content.queue_free()
	content = _build()
	add_child(content)
	UI.fade_in(content, 0.3)


func _big_icon(kind: String, px: int = 90) -> Control:
	var ring := PanelContainer.new()
	var col: Color = GIcon.default_color(kind)
	ring.add_theme_stylebox_override("panel", UI.style(col.darkened(0.75), col.darkened(0.2), 80, 4, 20))
	ring.add_child(GIcon.make(kind, px, col))
	return ring


func _arrow() -> Control:
	return GIcon.make("arrow", 54, UI.DIM)


func _build() -> Control:
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := UI.vbox(24)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	cc.add_child(v)

	var headline: String
	var sub: String
	var visual := UI.hbox(26)
	visual.alignment = BoxContainer.ALIGNMENT_CENTER
	match slide:
		0:
			headline = "Karten erzeugen HITZE"
			sub = "Mehr Hitze = mehr Schaden. Jedes Kästchen +10 %."
			visual.add_child(_big_icon("cards"))
			visual.add_child(_arrow())
			visual.add_child(_big_icon("heat"))
			visual.add_child(_arrow())
			visual.add_child(_big_icon("sword"))
		1:
			headline = "Zu heiß? KERNSCHMELZE!"
			sub = "Ist die Leiste voll und es kommt mehr dazu, tut es dir weh."
			var g := HeatGauge.new()
			g.setup(10, 10)
			g.set_preview(3)
			g.custom_minimum_size = Vector2(620, 100)
			visual.add_child(g)
			visual.add_child(_big_icon("skull", 70))
		_:
			headline = "Bring die Beute heim"
			sub = "Nach Etage 3 und 6: heimkehren oder weiter? Tod = Beute fast weg."
			visual.add_child(_big_icon("sword", 70))
			visual.add_child(_arrow())
			visual.add_child(_big_icon("home", 70))
			visual.add_child(UI.label("oder", 28, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER))
			visual.add_child(_big_icon("skull", 70))

	v.add_child(UI.title(headline, 54))
	v.add_child(visual)
	var sl := UI.label(sub, 26, UI.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	v.add_child(sl)

	var dots := UI.hbox(10)
	dots.alignment = BoxContainer.ALIGNMENT_CENTER
	for k in 3:
		var d := ColorRect.new()
		d.custom_minimum_size = Vector2(36 if k == slide else 14, 10)
		d.color = UI.EMBER if k == slide else Color(1, 1, 1, 0.2)
		dots.add_child(d)
	v.add_child(dots)

	var btns := UI.hbox(14)
	btns.alignment = BoxContainer.ALIGNMENT_CENTER
	btns.add_child(UI.button("Überspringen", func(): done.emit(), Vector2(190, 52), false, 18))
	var next_text: String = "Weiter" if slide < 2 else "Übungskampf starten"
	btns.add_child(UI.button(next_text, _next, Vector2(280, 56), true, 22))
	v.add_child(btns)
	return cc


func _next() -> void:
	slide += 1
	if slide >= 3:
		done.emit()
	else:
		refresh()
