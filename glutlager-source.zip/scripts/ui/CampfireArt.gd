class_name CampfireArt
extends Control
## Animiertes Lagerfeuer (nur Code, keine Bilddatei).

var t: float = 0.0


func _ready() -> void:
	custom_minimum_size = Vector2(0, 150)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _flame(cx: float, base: float, w: float, h: float, col: Color, phase: float) -> void:
	var flick: float = 0.85 + 0.15 * sin(t * 7.0 + phase) + 0.07 * sin(t * 13.0 + phase * 2.0)
	var sway: float = sin(t * 3.0 + phase) * w * 0.25
	var pts := PackedVector2Array([
		Vector2(cx - w, base),
		Vector2(cx - w * 0.8, base - h * 0.4 * flick),
		Vector2(cx - w * 0.3 + sway * 0.5, base - h * 0.75 * flick),
		Vector2(cx + sway, base - h * flick),
		Vector2(cx + w * 0.35 + sway * 0.5, base - h * 0.7 * flick),
		Vector2(cx + w * 0.85, base - h * 0.35 * flick),
		Vector2(cx + w, base),
	])
	draw_colored_polygon(pts, col)


func _draw() -> void:
	var cx: float = size.x * 0.5
	var base: float = size.y - 22.0
	var glow: float = 0.85 + 0.15 * sin(t * 5.0)
	draw_circle(Vector2(cx, base - 30), 100.0 * glow, Color(1.0, 0.4, 0.1, 0.08))
	draw_circle(Vector2(cx, base - 30), 70.0 * glow, Color(1.0, 0.5, 0.15, 0.1))
	# Holzscheite
	draw_line(Vector2(cx - 62, base + 8), Vector2(cx + 50, base - 12), Color(0.35, 0.22, 0.14), 14.0, true)
	draw_line(Vector2(cx + 62, base + 8), Vector2(cx - 50, base - 12), Color(0.42, 0.27, 0.16), 14.0, true)
	# Flammen
	_flame(cx - 20, base - 4, 22.0, 78.0, Color(0.95, 0.3, 0.08), 0.0)
	_flame(cx + 22, base - 4, 20.0, 66.0, Color(0.95, 0.35, 0.1), 2.0)
	_flame(cx, base - 2, 26.0, 96.0, Color(1.0, 0.5, 0.12), 1.0)
	_flame(cx, base, 15.0, 58.0, Color(1.0, 0.8, 0.3), 3.0)
	_flame(cx, base, 7.0, 32.0, Color(1.0, 0.97, 0.7), 4.0)
	# Funken
	for k in 7:
		var u: float = fposmod(t * 0.5 + k * 0.143, 1.0)
		var x: float = cx + sin(k * 2.7 + t) * 40.0 * u
		var y: float = base - 20.0 - u * 110.0
		draw_circle(Vector2(x, y), 2.4 * (1.0 - u), Color(1.0, 0.75, 0.3, 1.0 - u))
