class_name MapScreen
extends Control
## Run-Karte: Fortschrittspfad oben, darunter 2-3 große Kacheln zur Auswahl.
## Wenig Text: ein Wort + Symbole.

signal picked(choice_index: int)
signal deck_requested

var run: RunState


## Fortschrittspfad (Kreise, verbunden; Heimkehr-Punkte und Boss)
class PathBar extends Control:
	var floor_n: int = 1
	var boss_floor: int = 8
	var checkpoints: Array = []
	var t: float = 0.0

	func _ready() -> void:
		custom_minimum_size = Vector2(0, 84)
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _process(delta: float) -> void:
		t += delta
		queue_redraw()

	func _draw() -> void:
		var f: Font = ThemeDB.fallback_font
		var n: int = boss_floor
		var left: float = 60.0
		var right: float = size.x - 60.0
		var y: float = 46.0
		var step: float = (right - left) / float(n - 1)
		for i in n - 1:
			var done: bool = (i + 1) < floor_n
			draw_line(Vector2(left + i * step, y), Vector2(left + (i + 1) * step, y), Color(1.0, 0.48, 0.2, 0.9) if done else Color(1, 1, 1, 0.14), 6.0, true)
		for i in n:
			var fl: int = i + 1
			var p := Vector2(left + i * step, y)
			var is_boss: bool = fl == boss_floor
			var r: float = 24.0 if is_boss else 17.0
			if fl < floor_n:
				draw_circle(p, r, Color(0.55, 0.25, 0.1))
				draw_arc(p, r, 0, TAU, 28, Color(1.0, 0.55, 0.2), 3.0, true)
			elif fl == floor_n:
				var pulse: float = 1.0 + 0.12 * sin(t * 4.0)
				draw_circle(p, r * 1.5 * pulse, Color(1.0, 0.5, 0.15, 0.18))
				draw_circle(p, r, Color(1.0, 0.5, 0.15))
				draw_arc(p, r * pulse, 0, TAU, 28, Color(1.0, 0.9, 0.6), 3.0, true)
			else:
				draw_circle(p, r, Color(0.14, 0.12, 0.18))
				draw_arc(p, r, 0, TAU, 28, Color(1, 1, 1, 0.2), 2.0, true)
			var txt: String = "B" if is_boss else str(fl)
			if txt != "":
				draw_string(f, p + Vector2(-20, 7), txt, HORIZONTAL_ALIGNMENT_CENTER, 40, 20, Color(0.1, 0.05, 0.03) if fl == floor_n else Color(0.95, 0.9, 0.95))
			if checkpoints.has(fl):
				draw_rect(Rect2(p + Vector2(-7, 23), Vector2(14, 12)), Color(0.45, 0.85, 0.5))
				draw_colored_polygon(PackedVector2Array([p + Vector2(-11, 24), p + Vector2(0, 14), p + Vector2(11, 24)]), Color(0.45, 0.85, 0.5))


func setup(p_run: RunState) -> void:
	run = p_run


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var margin := UI.margin_box(26)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var root := UI.vbox(14)
	margin.add_child(root)

	# Kopfzeile
	var head := UI.hbox(14)
	head.add_child(UI.label("Etage %d" % run.floor_n, 40, UI.EMBER, HORIZONTAL_ALIGNMENT_LEFT, true))
	head.add_child(UI.spacer(false))
	head.add_child(UI.bar(run.hp, run.max_hp, UI.GOOD, "%d / %d" % [run.hp, run.max_hp], Vector2(250, 32)))
	head.add_child(UI.chip("scrap", str(run.scrap), UI.GOLD, 26, UI.PANEL_DARK, 28))
	var deck_btn := UI.button("", func(): deck_requested.emit(), Vector2(110, 46), false, 20)
	var dc := CenterContainer.new()
	dc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dc.add_child(UI.icon_row("cards", str(run.deck.size()), 26, 22))
	deck_btn.add_child(dc)
	UI.ignore_mouse(dc)
	deck_btn.tooltip_text = "Dein Deck ansehen"
	head.add_child(deck_btn)
	head.add_child(UI.button("?", _on_help, Vector2(46, 46), false, 22))
	root.add_child(head)

	var path := PathBar.new()
	path.floor_n = run.floor_n
	path.boss_floor = RunState.BOSS_FLOOR
	path.checkpoints = RunState.CHECKPOINTS
	root.add_child(path)

	var hint := UI.label("Wähle, wohin du als Nächstes gehst:   (grünes Haus = hier kannst du heimkehren)", 18, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER)
	root.add_child(hint)
	var row := UI.hbox(26)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for i in run.choices.size():
		row.add_child(_choice_tile(i))
	root.add_child(row)


func _on_help() -> void:
	var main: Node = get_parent()
	if main.has_method("show_overlay"):
		main.show_overlay(UI.help_overlay(main.close_overlay))


func _choice_tile(i: int) -> Control:
	var ch: Dictionary = run.choices[i]
	var title: String
	var sub: String
	var icon: String
	var col: Color
	match ch.type:
		"fight":
			title = "Kampf"
			sub = "Gegner besiegen,\nSchrott kassieren"
			icon = "sword"
			col = UI.BAD
		"elite":
			title = "Elite"
			sub = "Starker Gegner,\nmehr Schrott"
			icon = "skull"
			col = UI.GOLD
		"event":
			title = "Ereignis"
			sub = "Zufälliges Ereignis,\nmal gut, mal riskant"
			icon = "question"
			col = UI.BLUE
		"rest":
			title = "Rast"
			sub = "Leben auffüllen,\n1 Karte entfernen"
			icon = "flame"
			col = UI.GOOD
		_:
			title = "BOSS"
			sub = "Der Glutkern!\nBesiege ihn zum Sieg"
			icon = "skull"
			col = UI.EMBER
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(300, 400)
	btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	btn.focus_mode = Control.FOCUS_NONE
	btn.add_theme_stylebox_override("normal", UI.style(Color(0.13, 0.11, 0.17), col.darkened(0.15), 20, 3, 0))
	btn.add_theme_stylebox_override("hover", UI.style(Color(0.18, 0.15, 0.23), col.lightened(0.3), 20, 5, 0))
	btn.add_theme_stylebox_override("pressed", UI.style(Color(0.11, 0.09, 0.15), col, 20, 3, 0))
	btn.pressed.connect(func(): picked.emit(i))
	btn.pressed.connect(func(): Sfx.play("click"))
	var m := UI.margin_box(16)
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := UI.vbox(10)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	m.add_child(v)
	var ring := PanelContainer.new()
	ring.add_theme_stylebox_override("panel", UI.style(col.darkened(0.7), col, 64, 3, 14))
	ring.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ring.add_child(GIcon.make(icon, 84, col.lightened(0.15)))
	v.add_child(ring)
	v.add_child(UI.label(title, 34, col.lightened(0.2), HORIZONTAL_ALIGNMENT_CENTER, true))
	var sl := UI.label(sub, 17, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER)
	v.add_child(sl)
	# Details als Symbole
	if ch.has("enemies"):
		var thumbs := UI.hbox(0)
		thumbs.alignment = BoxContainer.ALIGNMENT_CENTER
		for id in ch.enemies:
			thumbs.add_child(EnemyArt.make(str(id), 74 if ch.type != "boss" else 96))
		v.add_child(thumbs)
		var loot: int = 0
		for id in ch.enemies:
			loot += int(EnemyDB.ENEMIES[id].scrap)
		var cc := CenterContainer.new()
		cc.add_child(UI.chip("scrap", "+%d" % loot, UI.GOLD, 20))
		v.add_child(cc)
	elif ch.type == "rest":
		var cc2 := CenterContainer.new()
		var r2 := UI.hbox(8)
		r2.add_child(UI.chip("heart", "+%d" % floori(run.max_hp * 0.3), UI.GOOD, 20))
		r2.add_child(UI.chip("cards", "−1", UI.TEXT, 20))
		cc2.add_child(r2)
		v.add_child(cc2)
	btn.add_child(m)
	UI.ignore_mouse(m)
	return btn
