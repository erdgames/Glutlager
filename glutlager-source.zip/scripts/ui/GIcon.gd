class_name GIcon
extends Control
## Zeichnet kleine Symbole (Schwert, Schild, Flamme ...) direkt per Code.
## So brauchen wir keine Bilddateien und die Symbole bleiben bei jeder Größe scharf.

const DARK := Color(0.07, 0.06, 0.09)

var kind: String = "sword"
var color: Color = Color.WHITE


static func make(p_kind: String, px: int = 28, p_color: Color = Color(-1, -1, -1)) -> GIcon:
	var i := GIcon.new()
	i.kind = p_kind
	i.color = p_color if p_color.r >= 0.0 else default_color(p_kind)
	i.custom_minimum_size = Vector2(px, px)
	i.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	i.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	i.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return i


## Standardfarbe pro Symbol
static func default_color(k: String) -> Color:
	match k:
		"sword": return Color(0.95, 0.42, 0.40)
		"shield": return Color(0.40, 0.72, 0.98)
		"heat": return Color(1.0, 0.45, 0.20)
		"flame", "burn": return Color(1.0, 0.62, 0.15)
		"snow": return Color(0.55, 0.88, 1.0)
		"bolt", "energy": return Color(1.0, 0.85, 0.30)
		"heart": return Color(0.95, 0.36, 0.45)
		"scrap", "gear": return Color(0.80, 0.74, 0.55)
		"cards": return Color(0.80, 0.82, 0.95)
		"skull": return Color(0.90, 0.88, 0.92)
		"home": return Color(0.55, 0.85, 0.55)
		_: return Color.WHITE


func _p(x: float, y: float) -> Vector2:
	return Vector2(x, y) * size


func _poly(pts: Array, col: Color) -> void:
	var arr := PackedVector2Array()
	for q in pts:
		arr.append(_p(q[0], q[1]))
	draw_colored_polygon(arr, col)


func _scaled(pts: Array, cx: float, cy: float, f: float) -> Array:
	var out: Array = []
	for q in pts:
		out.append([cx + (q[0] - cx) * f, cy + (q[1] - cy) * f])
	return out


func _draw() -> void:
	var s: float = minf(size.x, size.y)
	var c: Vector2 = size * 0.5
	match kind:
		"sword":
			draw_line(_p(0.2, 0.8), _p(0.82, 0.18), color, s * 0.17, true)
			draw_line(_p(0.2, 0.8), _p(0.82, 0.18), color.lightened(0.5), s * 0.05, true)
			_poly([[0.82, 0.18], [0.94, 0.06], [0.70, 0.12]], color)
			draw_line(_p(0.2, 0.46), _p(0.54, 0.80), color.darkened(0.25), s * 0.13, true)
			draw_line(_p(0.2, 0.8), _p(0.1, 0.9), color.darkened(0.45), s * 0.15, true)
		"shield":
			var sh: Array = [[0.14, 0.14], [0.5, 0.05], [0.86, 0.14], [0.86, 0.52], [0.5, 0.96], [0.14, 0.52]]
			_poly(sh, color)
			_poly(_scaled(sh, 0.5, 0.5, 0.62), color.darkened(0.3))
			_poly(_scaled(sh, 0.5, 0.5, 0.36), color.lightened(0.2))
		"heat":
			draw_line(_p(0.5, 0.2), _p(0.5, 0.62), color, s * 0.22, true)
			draw_circle(_p(0.5, 0.74), s * 0.22, color)
			draw_circle(_p(0.5, 0.74), s * 0.11, color.lightened(0.55))
			draw_line(_p(0.5, 0.3), _p(0.5, 0.62), color.lightened(0.55), s * 0.07, true)
			for k in 3:
				draw_line(_p(0.72, 0.22 + 0.14 * k), _p(0.84, 0.22 + 0.14 * k), color, s * 0.05, true)
		"flame", "burn":
			var fl: Array = [[0.50, 0.03], [0.64, 0.24], [0.80, 0.44], [0.85, 0.66], [0.75, 0.87], [0.50, 0.97], [0.25, 0.87], [0.15, 0.66], [0.21, 0.46], [0.34, 0.33], [0.40, 0.46], [0.46, 0.27]]
			_poly(fl, color)
			_poly(_scaled(fl, 0.5, 0.82, 0.55), color.lightened(0.45))
		"snow":
			for k in 3:
				var a: float = k * PI / 3.0
				var d := Vector2(cos(a), sin(a)) * s * 0.44
				draw_line(c - d, c + d, color, s * 0.1, true)
				var perp := Vector2(-sin(a), cos(a)) * s * 0.1
				for sgn in [-1.0, 1.0]:
					var tip: Vector2 = c + d * 0.6 * sgn
					draw_line(tip, tip - d * 0.2 * sgn + perp, color, s * 0.06, true)
					draw_line(tip, tip - d * 0.2 * sgn - perp, color, s * 0.06, true)
			draw_circle(c, s * 0.09, color.lightened(0.5))
		"bolt":
			_poly([[0.62, 0.03], [0.20, 0.56], [0.46, 0.56], [0.36, 0.97], [0.80, 0.40], [0.55, 0.40], [0.74, 0.03]], color)
		"energy":
			draw_circle(c, s * 0.46, color.darkened(0.55))
			draw_arc(c, s * 0.44, 0, TAU, 28, color, s * 0.06, true)
			_poly(_scaled([[0.62, 0.03], [0.20, 0.56], [0.46, 0.56], [0.36, 0.97], [0.80, 0.40], [0.55, 0.40], [0.74, 0.03]], 0.5, 0.5, 0.62), color)
		"heart":
			draw_circle(_p(0.32, 0.36), s * 0.21, color)
			draw_circle(_p(0.68, 0.36), s * 0.21, color)
			_poly([[0.12, 0.44], [0.88, 0.44], [0.5, 0.92]], color)
			draw_circle(_p(0.3, 0.3), s * 0.06, color.lightened(0.6))
		"gear":
			for k in 8:
				var a2: float = k * PI / 4.0
				var dir := Vector2(cos(a2), sin(a2))
				draw_line(c + dir * s * 0.28, c + dir * s * 0.46, color, s * 0.17, true)
			draw_circle(c, s * 0.34, color)
			draw_circle(c, s * 0.13, DARK)
		"scrap":
			var hx: Array = []
			for k in 6:
				var a3: float = k * PI / 3.0 + PI / 6.0
				hx.append([0.5 + cos(a3) * 0.45, 0.5 + sin(a3) * 0.45])
			_poly(hx, color)
			_poly(_scaled(hx, 0.5, 0.5, 0.78), color.darkened(0.18))
			draw_circle(c, s * 0.15, DARK)
		"cards":
			draw_rect(Rect2(_p(0.14, 0.2), Vector2(0.44, 0.62) * s), color.darkened(0.35))
			draw_rect(Rect2(_p(0.30, 0.12), Vector2(0.44, 0.62) * s), color.darkened(0.15))
			draw_rect(Rect2(_p(0.44, 0.22), Vector2(0.44, 0.62) * s), color)
			draw_rect(Rect2(_p(0.44, 0.22), Vector2(0.44, 0.62) * s), color.darkened(0.5), false, s * 0.04)
		"skull":
			draw_circle(_p(0.5, 0.42), s * 0.34, color)
			draw_rect(Rect2(_p(0.31, 0.6), Vector2(0.38, 0.28) * s), color)
			draw_circle(_p(0.37, 0.46), s * 0.09, DARK)
			draw_circle(_p(0.63, 0.46), s * 0.09, DARK)
			_poly([[0.5, 0.55], [0.45, 0.65], [0.55, 0.65]], DARK)
			for k in 3:
				draw_line(_p(0.4 + 0.1 * k, 0.76), _p(0.4 + 0.1 * k, 0.88), DARK, s * 0.03)
		"home":
			_poly([[0.5, 0.08], [0.94, 0.5], [0.80, 0.5], [0.80, 0.9], [0.20, 0.9], [0.20, 0.5], [0.06, 0.5]], color)
			draw_rect(Rect2(_p(0.42, 0.58), Vector2(0.16, 0.32) * s), DARK)
		"lock":
			draw_arc(_p(0.5, 0.36), s * 0.2, PI, TAU, 16, color, s * 0.1, true)
			draw_rect(Rect2(_p(0.2, 0.4), Vector2(0.6, 0.5) * s), color)
			draw_circle(_p(0.5, 0.62), s * 0.07, DARK)
		"arrow":
			_poly([[0.05, 0.38], [0.58, 0.38], [0.58, 0.14], [0.95, 0.5], [0.58, 0.86], [0.58, 0.62], [0.05, 0.62]], color)
		"question":
			var f: Font = ThemeDB.fallback_font
			draw_string(f, Vector2(0, s * 0.84), "?", HORIZONTAL_ALIGNMENT_CENTER, size.x, int(s * 1.05), color)
		_:
			draw_circle(c, s * 0.3, color)
