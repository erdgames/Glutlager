extends Node
## Spielt per Skript durch die ganze Oberfläche (Lager -> Run -> Kämpfe -> Ergebnis),
## um Fehler in den Bildschirmen zu finden.
## Start:  godot --headless --path . res://tests/UiTest.tscn -- 3

var main: Control


func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	var runs_wanted: int = int(args[0]) if args.size() > 0 else 2
	Game.data = Game.default_data()
	Game.data.scrap = 500
	var tut_mode: bool = args.size() > 1 and args[1] == "tut"
	Game.data.tutorial_done = not tut_mode
	main = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	var runs_done := 0
	var steps := 0
	var seen := {}
	while int(Game.data.stats.runs) < runs_wanted and steps < 6000:
		steps += 1
		await get_tree().process_frame
		var s: Control = main.screen
		if s == null:
			continue
		var kind: String = s.get_class() if s.get_script() == null else str(s.get_script().get_global_name())
		seen[kind] = int(seen.get(kind, 0)) + 1
		if s is CampScreen:
			if steps > 5 and main.run == null and seen.get("CampScreen", 0) > 2:
				# Werkbank/Gebäude testen
				Game.buy_building("kuehlturm")
				Game.buy_card("kettenreaktion")
				Game.buy_card("fusion")
				(s as CampScreen).refresh()
				s.start_run.emit("brenner" if runs_done % 2 == 1 else "techniker")
				seen["CampScreen"] = 0
		elif s is MapScreen:
			s.picked.emit(0)
		elif s is BattleScreen:
			if not s.busy:
				if s.tutorial:
					_play_tutorial(s)
				else:
					_play_battle(s)
		elif s is IntroScreen:
			(s as IntroScreen)._next()
		else:
			var btns: Array = []
			_all_buttons(s, btns)
			if not btns.is_empty():
				var btn: Button = btns.pick_random()
				btn.pressed.emit()
				if main.overlay != null:
					# Deck-Overlay (Karte entfernen): erste Karte wählen
					var cb := _first_button(main.overlay, true)
					if cb != null:
						cb.pressed.emit()
	print("UI-Test fertig. Runs: %d, Schritte: %d, Bildschirme: %s" % [Game.data.stats.runs, steps, seen])
	print("Spielstand: ", Game.data)
	get_tree().quit()


func _play_tutorial(s: BattleScreen) -> void:
	var b: Battle = s.b
	if b.state != "player":
		s.finished.emit(b.state)
		return
	var st: Dictionary = s._tut_step()
	if st.is_empty() or st.wait == "free":
		_play_battle(s)
	elif st.wait == "next":
		s._tut_advance()
	elif st.wait == "end":
		s._on_end_turn()
	else:
		var id: String = st.wait.split(":")[1]
		var idx: int = b.hand.find(id)
		if idx >= 0:
			await s._on_card(idx)
			if s.end_btn != null and s.end_btn.disabled and s.b.state == "player":
				print("BUTTON-FEHLER: Zug beenden gesperrt nach Kartenzug")
		else:
			print("TUTORIAL-FEHLER: Karte fehlt: ", id, " Hand: ", b.hand)
			s._on_end_turn()


func _play_battle(s: BattleScreen) -> void:
	var b: Battle = s.b
	if b.state != "player":
		s.finished.emit(b.state)
		return
	var played := false
	for i in b.hand.size():
		var id: String = b.hand[i]
		if b.can_play(i) and b.heat + int(CardDB.CARDS[id].get("heat", 0)) <= b.heat_limit:
			await s._on_card(i)
			if s.end_btn != null and s.end_btn.disabled and s.b.state == "player":
				print("BUTTON-FEHLER: Zug beenden gesperrt nach Kartenzug")
			played = true
			break
	if not played:
		await s._on_end_turn()
		if s.end_btn != null and s.end_btn.disabled and s.b.state == "player":
			print("BUTTON-FEHLER: Zug beenden gesperrt nach Gegnerzug")


func _all_buttons(n: Node, out: Array) -> void:
	if n is Button and not n.disabled:
		out.append(n)
	for c in n.get_children():
		_all_buttons(c, out)


func _first_button(n: Node, last_ok: bool = false) -> Button:
	if n is Button and not n.disabled and (n.text != "" or last_ok):
		return n
	for c in n.get_children():
		var r := _first_button(c, last_ok)
		if r != null:
			return r
	return null
