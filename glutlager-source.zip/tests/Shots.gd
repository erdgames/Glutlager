extends Node
## Macht Screenshots der wichtigsten Bildschirme (braucht ein echtes/virtuelles Display).
## Start:  xvfb-run godot --path . res://tests/Shots.tscn -- /pfad/zum/ordner

var main: Control
var out_dir := "/tmp/shots"

func _shot(name: String, wait: float = 0.5) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().create_timer(wait).timeout
	var img := get_viewport().get_texture().get_image()
	img.save_png("%s/%s.png" % [out_dir, name])

func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() > 0:
		out_dir = args[0]
	DirAccess.make_dir_recursive_absolute(out_dir)
	Game.data = Game.default_data()
	Game.data.scrap = 70
	Game.data.tutorial_done = false
	Sfx.enabled = false
	Sfx.music.stop()
	main = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	await _shot("01_intro1")
	main.screen._next()
	await _shot("02_intro2")
	main.screen._next()
	await _shot("03_intro3")
	main.screen._next()
	await _shot("04_tutorial_start", 0.9)
	var s: BattleScreen = main.screen
	s._tut_advance()
	await _shot("05_tutorial_hand", 0.7)
	s._tut_advance()
	await get_tree().create_timer(0.3).timeout
	s._on_card(s.b.hand.find("funke"))
	await _shot("06_tutorial_nach_funke", 1.2)
	Game.data.tutorial_done = true
	main.show_camp()
	await _shot("07_lager", 0.8)
	main._on_start_run("techniker")
	await _shot("08_karte", 0.8)
	var ch := {"type": "fight", "enemies": ["wolf", "drohne"]}
	main.run.floor_n = 4
	main.start_battle(ch, "Etage 4")
	await _shot("09_kampf_start", 0.8)
	var bs: BattleScreen = main.screen
	bs.b.heat = 7
	bs.refresh()
	bs.gauge.set_preview(3)
	await _shot("10_kampf_hitze", 0.5)
	main.show_reward(22)
	await _shot("11_belohnung", 0.8)
	main.show_checkpoint()
	await _shot("12_wegkreuzung", 0.6)
	main.show_event()
	await _shot("13_ereignis", 0.6)
	main.show_rest()
	await _shot("14_rast", 0.6)
	main.run.fights_won = 5
	main.finish_run("retreat")
	await _shot("15_ergebnis", 0.6)
	main.show_overlay(UI.help_overlay(main.close_overlay))
	await _shot("16_hilfe", 0.4)
	get_tree().quit()
