extends Node
## Balancing-Simulation: ein einfacher Bot spielt viele Runs, damit wir sehen,
## ob das Spiel zu leicht oder zu schwer ist.
## Start:  godot --headless --path . res://tests/Sim.tscn -- 200 techniker

func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	var runs: int = int(args[0]) if args.size() > 0 else 100
	var cls: String = args[1] if args.size() > 1 else "techniker"
	var unlock_all: bool = args.size() > 2 and args[2] == "all"
	var wins := 0
	var deaths_at := {}
	var turns_total := 0
	var fights_total := 0
	var melt_total := 0
	for r in runs:
		var g: Node = Game
		g.data = g.default_data()
		if unlock_all:
			g.data.unlocked_cards = CardDB.CARDS.keys()
		var run := RunState.create(cls)
		var res := _play_run(run)
		turns_total += res.turns
		fights_total += res.fights
		melt_total += res.melts
		if res.won:
			wins += 1
		else:
			deaths_at[res.floor] = int(deaths_at.get(res.floor, 0)) + 1
	print("Klasse %s | Runs %d | Siege %.1f%% | Ø Züge/Kampf %.1f | Ø Kernschmelzen/Run %.2f" % [cls, runs, 100.0 * wins / runs, float(turns_total) / maxf(1.0, fights_total), float(melt_total) / runs])
	print("Tod pro Etage: ", deaths_at)
	get_tree().quit()


func _play_run(run: RunState) -> Dictionary:
	var turns := 0
	var fights := 0
	var melts := 0
	while true:
		var ch: Dictionary = run.choices[0]
		# Bot: bei wenig Leben lieber Rast, sonst Kampf
		for c in run.choices:
			if c.type == "rest" and run.hp < run.max_hp * 0.6:
				ch = c
		match ch.type:
			"rest":
				run.hp = mini(run.max_hp, run.hp + floori(run.max_hp * 0.3))
			"event":
				pass
			_:
				var ids: Array = ["glutkern"] if ch.type == "boss" else EnemyDB.pick_fight(run.floor_n, ch.type == "elite")
				var b := Battle.new()
				b.setup(run.hp, run.max_hp, run.deck, run.heat_limit, run.cooling, ids, run.floor_n)
				var guard := 0
				while b.state == "player" and guard < 60:
					_bot_turn(b)
					if b.state == "player":
						b.end_turn()
					guard += 1
				turns += b.turn
				fights += 1
				melts += b.meltdowns
				run.hp = b.hp
				if b.state == "lost" or guard >= 60:
					return {"won": false, "floor": run.floor_n, "turns": turns, "fights": fights, "melts": melts}
				if ch.type == "boss":
					return {"won": true, "floor": run.floor_n, "turns": turns, "fights": fights, "melts": melts}
				var opts := run.reward_cards()
				if run.deck.size() < 18 and not opts.is_empty():
					run.deck.append(_bot_pick(opts))
		run.floor_n += 1
		run.make_choices()
	return {}


func _bot_pick(opts: Array) -> String:
	return opts[randi() % opts.size()]


func _bot_turn(b: Battle) -> void:
	var safety := 0
	while safety < 12:
		safety += 1
		var best := -1
		var best_score := -999.0
		var incoming := 0
		for e in b.alive_enemies():
			if e.intent.has("dmg"):
				incoming += int(e.intent.dmg)
			if e.intent.has("heat"):
				incoming += int(e.intent.heat) * 2
		for i in b.hand.size():
			if not b.can_play(i):
				continue
			var c: Dictionary = CardDB.CARDS[b.hand[i]]
			var heat_after: int = b.heat + int(c.get("heat", 0)) - (b.heat if c.get("special", "") == "heat_dump" else 0)
			heat_after -= int(c.get("cool", 0))
			if heat_after > b.heat_limit:
				continue
			var score := 0.0
			var m := b.mult()
			score += float(c.get("dmg", 0)) * m * float(c.get("hits", 1)) * (1.5 if c.get("aoe", false) and b.alive_enemies().size() > 1 else 1.0)
			if c.get("special", "") == "heat_dump":
				score += 3.0 * b.heat * m
			if c.get("special", "") == "per_card":
				score += 3.0 * b.played.size()
			var need_block: int = maxi(0, incoming - b.block)
			score += minf(float(c.get("blk", 0)) * m, float(need_block)) * 1.1
			score += float(c.get("draw", 0)) * 3.0 + float(c.get("energy", 0)) * 4.0 + float(c.get("burn", 0)) * 2.0
			score += float(c.get("cool", 0)) * (1.0 if b.heat > b.heat_limit - 4 else 0.2)
			score += float(c.get("heal", 0)) * (1.5 if b.hp < b.max_hp * 0.6 else 0.0)
			if c.get("special", "") == "hot_runner":
				score += 2.0
			score += float(b.resonance_bonus_for(b.hand[i]))
			score /= maxf(1.0, float(c.cost))
			if int(c.cost) == 0:
				score += 2.0
			if score > best_score:
				best_score = score
				best = i
		if best < 0 or best_score <= 0.5:
			return
		b.play_card(best, 0)
		if b.state != "player":
			return
