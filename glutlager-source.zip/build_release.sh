#!/bin/bash
# Baut Version 0.2.0 für alle Plattformen. Benötigt: Godot 4.3 + Export-Templates, makensis (NSIS), python3.
# Pfade bei Bedarf über Umgebungsvariablen setzen:  GODOT=... NSIS=...
set -e
cd "$(dirname "$0")"
GODOT=${GODOT:-godot}
NSIS=${NSIS:-makensis}
VER=0.2.3
mkdir -p build/windows build/linux build/macos dist
$GODOT --headless --path . --import
$GODOT --headless --path . --export-release "Windows Desktop" build/windows/Glutlager.exe
$GODOT --headless --path . --export-release "Linux" build/linux/glutlager
$GODOT --headless --path . --export-release "macOS" build/macos/Glutlager.zip
( cd installer/windows && $NSIS glutlager.nsi )
echo "Fertig. Weitere Schritte (Arch-Paket, macOS-ZIPs je Architektur) siehe README."
