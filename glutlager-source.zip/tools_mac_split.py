import sys, zipfile, struct, os
src, out, ver = sys.argv[1:4]
z = zipfile.ZipFile(src)
names = z.namelist()
binname = [n for n in names if n.endswith("Contents/MacOS/Glutlager")][0]
data = z.read(binname)
magic = struct.unpack(">I", data[:4])[0]
assert magic == 0xCAFEBABE, "kein Universal-Binary"
n = struct.unpack(">I", data[4:8])[0]
slices = {}
for i in range(n):
    cpu, sub, off, size, al = struct.unpack(">iiIII", data[8 + 20*i: 28 + 20*i])
    slices[{0x01000007: "x86_64", 0x0100000C: "arm64"}[cpu]] = data[off:off+size]
label = {"arm64": "AppleSilicon-arm64", "x86_64": "Intel-x86_64"}
for arch, blob in slices.items():
    path = f"{out}/Glutlager-macOS-{ver}-{label[arch]}.zip"
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as o:
        for nm in names:
            if nm.endswith("/"): continue
            zi = zipfile.ZipInfo(nm, date_time=(2026, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.create_system = 3
            zi.external_attr = (0o755 if nm == binname else 0o644) << 16
            o.writestr(zi, blob if nm == binname else z.read(nm))
    print(path, os.path.getsize(path))
