# Glutlager

Roguelite-Deckbuilder für Windows, macOS und Linux. Komplett offline, Spielstand als JSON-Datei.
Engine: Godot 4.3 (GDScript). Alle Grafiken sind Code-Formen (Platzhalter) – leicht austauschbar.

## Spielidee
Karten erzeugen **Hitze**. Mehr Hitze = mehr Schaden und Schild (+10 % pro Punkt) – aber über dem
Limit droht die **Kernschmelze**. Gleiche Tags hintereinander lösen **Resonanz** aus (+2).
Nach Etage 3 und 6 entscheidest du: **Rückzug** ins Lager (Beute sicher) oder **weiter** (Risiko: bei
Tod nur 30 % Beute). Mit Schrott baust du das Lager aus, schaltest Karten und Klassen frei.

## Ordner
- `scripts/core/`   Battle.gd (Kampflogik), RunState.gd (Run-Zustand und Karten-Generierung)
- `scripts/data/`   CardDB, EnemyDB, EventDB, HeroDB – hier Inhalte ergänzen/balancen
- `scripts/ui/`     Bildschirme (Lager, Karte, Kampf) und UI-Bausteine
- `scripts/Game.gd` Speichern/Laden + Lager-Fortschritt, `scripts/Main.gd` Spielablauf
- `tests/`          Bot-Simulation (Balancing), UI-Durchlauf, Screenshot-Skript
- `installer/`      Windows (NSIS), Arch (PKGBUILD), Linux (install.sh), macOS (Anleitung)

## Starten / Testen (Godot 4.3 nötig)
    godot --path .                                           # Spiel starten
    godot --headless --path . res://tests/Sim.tscn -- 300 techniker   # Balancing-Simulation
    godot --headless --path . res://tests/UiTest.tscn -- 5            # Oberflächen-Durchlauf
